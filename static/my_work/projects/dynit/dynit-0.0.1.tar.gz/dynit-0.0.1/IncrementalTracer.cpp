/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <set>
#include <map>
#include <stack>
#include <algorithm>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"
#include "inserters.h"
#include "generate_trace_snippet.h"
#include "IncrementalTracer.h"
#include "util.h"
#include "commands.h"
#include "snippet_library.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

IncrementalTracer::IncrementalTracer( BPatch_thread * i_app_thr,
				      BPatch_image * i_app_img )
{
  level = 0;

  application_thread = i_app_thr;
  application_image  = i_app_img;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

bool IncrementalTracer::Continue()
{
  bool done = false;
  while( ! done )
    {
      application_thread->continueExecution();

      while( ! application_thread->isStopped() && ! application_thread->isTerminated() )
	{
	  usleep( 500000 );
	}

      if( application_thread->isStopped() )
	{
	  char line[ 1024 + 1 ];
	  int size = 0;
	  while( read( fd, & line[ size ], 1 ) == 1 )
	    {
	      size++;
	    }
	  line[ size ] = '\0';
	  for( int i = 0; i < size; i++ ) if( line[ i ] == '\n' ) line[ i ] = '\0';

	  int call_number;
	  char * function_name;

	  switch( line[ 0 ] )
	    {
	    case '>':
	      function_name = line + 1;
	      level++;
	      for( int i = 0; i < level; i++ ) cout << "  "; cout<<">"<<function_name<<">"<<endl;
	      if( _IsSelectedForTrace( function_name ) )
		{
		  if( before_call_snippets[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      before_call_snippets[ fcn_idx( function_name ) ] =
			insert_before_calls( application_image->findFunction( function_name ) );
		    }
		  if( after_call_snippets[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      after_call_snippets[ fcn_idx( function_name ) ] =
			insert_after_calls( application_image->findFunction( function_name ) );
		    }
		}

	      stopped_at_point = BPatch_entry;
	      stopped_at_function = string( function_name );
	      break;

	    case '<':
	      {
		function_name = line + 1;
		for( int i = 0; i < level; i++ ) cout << "  ";
		cout << "<" << function_name << "<" << endl;
		level--;
	      }
	      for( map<int, BPatchSnippetHandle *>::iterator index =
		     before_call_snippets[ fcn_idx( function_name ) ].begin();
		   index != before_call_snippets[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  application_thread->deleteSnippet( index->second );
		}
	      for( map<int, BPatchSnippetHandle *>::iterator index =
		     after_call_snippets[ fcn_idx( function_name ) ].begin();
		   index != after_call_snippets[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  application_thread->deleteSnippet( index->second );
		}
	      before_call_snippets[ fcn_idx( function_name ) ].clear();
	      after_call_snippets[ fcn_idx( function_name ) ].clear();

	      stopped_at_point = BPatch_exit;
	      stopped_at_function = string( function_name );
	      break;

	    case '+':
	      {
		char * temp;
		temp = strstr( line, ":" ); sscanf( temp + 1, "%d", & call_number ); * temp = '\0';
		temp = strstr( temp + 1, ":" ); function_name = strstr( temp, ":" ) + 1;
		if( function_name == 0 ) { function_name = "null"; }
	      }
	      for( int i = 0; i < level; i++ ) cout << "  "; cout << "+" << function_name << endl;
	      if( _IsSelectedForTrace( function_name ) )
		{
		  if( entry_snippets[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      BPatch_snippet * snippet =
			gen_entry_snippet( application_thread, pipe_name, function_name );
		      entry_snippets[ fcn_idx( function_name ) ] =
			insert_at_entry_points( application_image->findFunction( function_name ),
						snippet );
		    }
		  if( exit_snippets[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      BPatch_snippet * snippet =
			gen_exit_snippet( application_thread, pipe_name, function_name );
		      exit_snippets[ fcn_idx( function_name ) ] =
			insert_at_exit_points( application_image->findFunction( function_name ),
					       snippet );
		    }
		}

	      stopped_at_point = BPatch_subroutine;
	      stopped_at_function = string( function_name );
	      break;

	    case '-':
	      {
		char * temp;
		temp = strstr( line, ":" ); sscanf( temp + 1, "%d", & call_number ); * temp = '\0';
		temp = strstr( temp + 1, ":" ); function_name = strstr( temp, ":" ) + 1;
		if( function_name == 0 ) { function_name = "null"; }
	      }
	      for( int i = 0; i < level; i++ ) cout << "  "; cout << "-" << function_name << endl;
	      for( set<BPatchSnippetHandle *>::iterator index =
		     entry_snippets[ fcn_idx( function_name ) ].begin();
		   index != entry_snippets[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  application_thread->deleteSnippet( * index );
		}
	      for( set<BPatchSnippetHandle *>::iterator index =
		     exit_snippets[ fcn_idx( function_name ) ].begin();
		   index != exit_snippets[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  application_thread->deleteSnippet( * index );
		}
	      entry_snippets[ fcn_idx( function_name ) ].clear();
	      exit_snippets[ fcn_idx( function_name ) ].clear();

	      stopped_at_point = BPatch_subroutine;
	      stopped_at_function = string( function_name );
	      break;

	    case 'b':
	      if( strstr( line, "b:>" ) == line )
		{
		  function_name = line + 3;
		  cout << "Program stopped on entry to " << function_name << "." << endl;
		  stopped_at_point = BPatch_entry;
		}
	      else if( strstr( line, "b:<" ) == line )
		{
		  function_name = line + 3;
		  cout << "Program stopped on exit from " << function_name << "." << endl;
		  stopped_at_point = BPatch_exit;
		}

	      stopped_at_function = string( function_name );
	      break;

	    default:
	      cout << "Scrambled transmission: " << endl; 
	      cout << line << endl;
	      break;

	    } // end of switch
	}

      done = true; // application_thread->isTerminated();
    }

  return true;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

bool IncrementalTracer::AddToTraceList( string_set_type & in_set )
{
  for( string_set_type::iterator index = in_set.begin();
       index != in_set.end();
       index++ )
    {
      char * function_name = ( char * )( index->data() );

      if( ! _IsSelectedForTrace( function_name ) )
	{
 	  traced_functions.insert( * index );

	  BPatch_snippet * snippet =
	    gen_entry_snippet( application_thread, pipe_name, function_name );
	  entry_snippets[ fcn_idx( function_name ) ] =
	    insert_at_entry_points( application_image->findFunction( function_name ),
				    snippet );
	}
    }

  return true;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

bool IncrementalTracer::RemoveFromTraceList( string_set_type & in_set )
{
  for( string_set_type::iterator index = in_set.begin();
       index != in_set.end();
       index++ )
    {
      char * function_name = ( char * )( index->data() );

      if( _IsSelectedForTrace( function_name ) )
	{
	  // 	  traced_functions.erase( * index );

	  for( snippethandle_set_type::iterator snipp =
		 entry_snippets[ fcn_idx( function_name ) ].begin();
	       snipp != entry_snippets[ fcn_idx( function_name ) ].end();
	       snipp++ )
	    {
	      application_thread->deleteSnippet( * snipp );
	    }
	  entry_snippets[ fcn_idx( function_name ) ].clear();
	}
    }

  return true;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

bool IncrementalTracer::RemoveAllFromTraceList()
{
  return true;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

bool IncrementalTracer::_IsSelectedForTrace( char * function_name )
{
  if( function_name == 0 )
    {
      return false;
    }

  bool found =
    find( traced_functions.begin(), traced_functions.end(),
	  string( function_name ) )
    !=
    traced_functions.end();

  return found;
}
