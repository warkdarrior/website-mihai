#ifndef _MAIN_h_

#define _MAIN_h_

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

typedef set<BPatchSnippetHandle * >      snippethandle_set_type;
typedef map<int, BPatchSnippetHandle * > snippethandle_map_type;

typedef set<char * >                     chararray_set_type;
typedef set<string >                     string_set_type;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

extern BPatch bpatch;

extern BPatch_image *  appImage;
extern BPatch_thread * appThread;

extern BPatch_variableExpr * level_var;
extern BPatch_variableExpr * trace_flag;

extern BPatch_Vector<BPatch_function * > *  functions;

extern int    fd;
extern char   pipe_name[ 1024 + 1 ];
extern char * log_file_name;

extern map<int, snippethandle_set_type > snippets_at_beginning_of;
extern map<int, snippethandle_set_type > snippets_at_end_of;
extern map<int, snippethandle_map_type > snippets_before_call_in;
extern map<int, snippethandle_map_type > snippets_after_call_in;

extern map<int, snippethandle_set_type > break_entry_snippets;
extern map<int, snippethandle_set_type > break_exit_snippets;

extern BPatch_procedureLocation stopped_at_point;
extern string                   stopped_at_function;

extern string_set_type trace_selections;
extern string_set_type exclusions;
extern string_set_type preferred;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

int  fcn_idx               ( char * name );
// bool is_selected_for_trace ( char * name );

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#endif
