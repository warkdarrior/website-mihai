/* testprog.c */

/* a cheesy program to test out Rob's
 * ignorance of DynInst
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>

void myprintf( char * format, ... );
void fakeprintf( char * format, ... );

int leaf() {    return 0;    }

int leaf2(int x) {    return x>0;    }

int baz() {
  fakeprintf("baz()\n");
  return 0;
}

int ourglobal = 0;

int bar() {
  rand();
  baz();
  ourglobal++;
  return 1;
}

void foo() {
  fakeprintf("foo\n");
  bar();
  bar();
}


int main() {
  int i;
  char * s;

  for (i=0; i< 4 ; i++) {
    fakeprintf("testprog: iteration %d\n", i);
    foo();
  }
  baz();
  fakeprintf(" before main->leaf()\n" );
  leaf();
  fakeprintf(" before main->leaf2()\n" );
  leaf2(5);
  fakeprintf(" before main->foo()\n" );
  foo();

  s = ( char * )malloc( 100 );
  strcpy( s, "asv" );
  free( s );

  return 0;
}

void fakeprintf( char * format, ... )
{
  char message[ 1024 + 1 ];

  va_list arg_list;
  va_start( arg_list, format );
  vsnprintf( message, 1024, format, arg_list );
  va_end( arg_list );

  fprintf( stdout, "%s", message );
}

void myprintf( char * format, ... )
{
  char message[ 1024 + 1 ];

  va_list arg_list;
  va_start( arg_list, format );
  vsnprintf( message, 1024, format, arg_list );
  va_end( arg_list );

  fprintf( stdout, "myprintf: %s", message );
}
