BPatch_snippet * gen_trace_snippet( BPatch_thread * app_thread,
				    char * trace_file,
				    char * trace_msg 
				    );
BPatch_snippet * gen_cool_trace_snippet( BPatch_thread * app_thread,
					 char * trace_file,
					 char * trace_msg,
					 bool end_of_func );

BPatch_snippet * gen_trace_and_stop_snippet( BPatch_thread * app_thread,
					     char * trace_file,
					     char * trace_msg,
					     bool end_of_func
					     );
