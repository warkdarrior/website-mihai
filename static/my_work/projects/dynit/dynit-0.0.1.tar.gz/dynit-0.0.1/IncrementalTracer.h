#ifndef _Incremental_Trace_Class_h_

#define _Incremental_Trace_Class_h_

class IncrementalTracer
{

 private:

  int                               level;

  BPatch_thread *                   application_thread;
  BPatch_image  *                   application_image;

  string_set_type                   traced_functions;
  map<int, snippethandle_set_type > trace_snippets;

  map<int, snippethandle_set_type > entry_snippets;
  map<int, snippethandle_set_type > exit_snippets;
  map<int, snippethandle_map_type > before_call_snippets;
  map<int, snippethandle_map_type > after_call_snippets;

  string                            stopped_at_function;
  BPatch_procedureLocation          stopped_at_point;

 public:

  IncrementalTracer( BPatch_thread *,
		     BPatch_image * );

  bool Continue();


  bool AddToTraceList( string_set_type & );
  bool RemoveFromTraceList( string_set_type & );
  bool RemoveAllFromTraceList();

 private:

  bool _IsSelectedForTrace( char * );

};

#endif
