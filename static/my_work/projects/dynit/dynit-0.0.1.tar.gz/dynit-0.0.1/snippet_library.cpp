/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "BPatch.h"
#include "BPatch_Vector.h"
#include "BPatch_image.h"
#include "BPatch_module.h"
#include "BPatch_point.h"
#include "BPatch_snippet.h"
#include "BPatch_thread.h"
#include "BPatch_type.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <iostream>
#include <set>
#include <map>
#include <string>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

static char * trace_func_name       = "trace_to_file";
static char * trace_value_func_name = "trace_value_to_file";
static char * library_name          = "libcool_trace.so";

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void initialize_trace_variables( BPatch_thread * app_thread )
{
  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "getImage() failed." << endl; assert( 0 ); }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_funcCallExpr * gen_trace_to_file_snippet( BPatch_thread * app_thread,
						 char * file_name,
						 char * message )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  BPatch_constExpr * ttfcall_arg_filename =
    new BPatch_constExpr( file_name );
  BPatch_constExpr * ttfcall_arg_message =
    new BPatch_constExpr( message );

  BPatch_Vector<BPatch_snippet *> * ttfcall_args =
    new BPatch_Vector<BPatch_snippet *>;
  ttfcall_args->push_back( ttfcall_arg_filename );
  ttfcall_args->push_back( ttfcall_arg_message );

  BPatch_function * ttfcall_func =
    app_image->findFunction( trace_func_name );
  if( ttfcall_func == 0 )
    {
      if( ! app_thread->loadLibrary( library_name ) )
	{ cout << "app_thread->loadLibrary( library_name ) failed." << endl; assert( 0 ); }
      else
	{ cout << "=- Library '" << library_name << "' loaded." << endl; }
      ttfcall_func = app_image->findFunction( trace_func_name );
      if( ttfcall_func == 0 ) { cout << "app_image->findFunction( trace ) not found." << endl; assert( 0 ); }
    }

  return new BPatch_funcCallExpr( * ttfcall_func, * ttfcall_args );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_funcCallExpr * gen_trace_value_to_file_snippet( BPatch_thread * app_thread,
						       char * file_name,
						       char * message )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  BPatch_constExpr * tvtfcall_arg_filename =
    new BPatch_constExpr( file_name );
  BPatch_constExpr * tvtfcall_arg_message =
    new BPatch_constExpr( message );

  BPatch_Vector<BPatch_snippet *> * tvtfcall_args =
    new BPatch_Vector<BPatch_snippet *>;
  tvtfcall_args->push_back( tvtfcall_arg_filename );
  tvtfcall_args->push_back( tvtfcall_arg_message );
  tvtfcall_args->push_back( new BPatch_retExpr() );

  BPatch_function * tvtfcall_func =
    app_image->findFunction( trace_value_func_name );
  if( tvtfcall_func == 0 )
    {
      if( ! app_thread->loadLibrary( library_name ) )
	{ cout << "app_thread->loadLibrary( library_name ) failed." << endl; assert( 0 ); }
      else
	{ cout << "=- Library '" << library_name << "' loaded." << endl; }
      tvtfcall_func = app_image->findFunction( trace_value_func_name );
      if( tvtfcall_func == 0 ) { cout << " not found." << endl; assert( 0 ); }
    }

  return new BPatch_funcCallExpr( * tvtfcall_func, * tvtfcall_args );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_funcCallExpr * gen_trace_formatted_value_snippet( BPatch_thread * app_thread,
							 char * file_name,
							 char * format,
							 BPatch_snippet * value )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  BPatch_constExpr * tvtfcall_arg_filename =
    new BPatch_constExpr( file_name );
  BPatch_constExpr * tvtfcall_arg_format =
    new BPatch_constExpr( format );

  BPatch_Vector<BPatch_snippet *> * tvtfcall_args =
    new BPatch_Vector<BPatch_snippet *>;
  tvtfcall_args->push_back( tvtfcall_arg_filename );
  tvtfcall_args->push_back( tvtfcall_arg_format );
  tvtfcall_args->push_back( value );

  BPatch_function * tvtfcall_func =
    app_image->findFunction( trace_value_func_name );
  if( tvtfcall_func == 0 )
    {
      if( ! app_thread->loadLibrary( library_name ) )
	{ cout << "app_thread->loadLibrary( library_name ) failed." << endl; assert( 0 ); }
      else
	{ cout << "=- Library '" << library_name << "' loaded." << endl; }
      tvtfcall_func = app_image->findFunction( trace_value_func_name );
      if( tvtfcall_func == 0 ) { cout << " not found." << endl; assert( 0 ); }
    }

  return new BPatch_funcCallExpr( * tvtfcall_func, * tvtfcall_args );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_funcCallExpr * gen_print_spaces_snippet( BPatch_thread * app_thread,
						char * file_name )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  BPatch_constExpr * pscall_arg_filename =
    new BPatch_constExpr( file_name );

  BPatch_Vector<BPatch_snippet *> * pscall_args =
    new BPatch_Vector<BPatch_snippet *>;
  pscall_args->push_back( pscall_arg_filename );
  pscall_args->push_back( level_var );

  BPatch_function * pscall_func =
    app_image->findFunction( trace_func_name );
  if( pscall_func == 0 )
    {
      if( ! app_thread->loadLibrary( library_name ) )
	{ cout << "app_thread->loadLibrary( library_name ) failed." << endl; assert( 0 ); }
      else
	{ cout << "=- Library '" << library_name << "' loaded." << endl; }
      pscall_func = app_image->findFunction( trace_func_name );
      if( pscall_func == 0 ) { cout << " not found." << endl; assert( 0 ); }
    }

  return new BPatch_funcCallExpr( * pscall_func, * pscall_args );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_entry_snippet( BPatch_thread * app_thread,
				    char * pipe_file,
				    char * func_name,
				    char * message_prefix
				    )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  char message[ 1024 + 1 ];
  sprintf( message, "%s%s", message_prefix, func_name );
  BPatch_funcCallExpr * trace_call =
    gen_trace_to_file_snippet( app_thread, pipe_file, message );

  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;

  tracestmt->push_back( trace_call );
  tracestmt->push_back( stophere );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_exit_snippet( BPatch_thread * app_thread,
				    char * pipe_file,
				    char * func_name,
				    char * message_prefix
				    )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  char message[ 1024 + 1 ];
  sprintf( message, "%s%s", message_prefix, func_name );
  BPatch_funcCallExpr * trace_call =
    /* gen_trace_value_to_file_snippet( app_thread, pipe_file, message ); */
    gen_trace_to_file_snippet( app_thread, pipe_file, message );

  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;

  tracestmt->push_back( trace_call );
  tracestmt->push_back( stophere );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_before_snippet( BPatch_thread * app_thread,
				     char * pipe_file,
				     char * subroutine_name
				     )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  char message[ 1024 + 1 ];
  sprintf( message, "+%s", subroutine_name );
  BPatch_funcCallExpr * trace_call =
    gen_trace_to_file_snippet( app_thread, pipe_file, message );

  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;

  tracestmt->push_back( trace_call );
  tracestmt->push_back( stophere );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_after_snippet( BPatch_thread * app_thread,
				    char * pipe_file,
				    char * subroutine_name
				    )
{
  initialize_trace_variables( app_thread );

  BPatch_image * app_image = app_thread->getImage();
  if( app_image == 0 ) { cout << "app_thread->getImage() failed." << endl; assert( 0 ); }

  char message[ 1024 + 1 ];
  sprintf( message, "-%s", subroutine_name );
  BPatch_funcCallExpr * trace_call =
    gen_trace_to_file_snippet( app_thread, pipe_file, message );

  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;

  tracestmt->push_back( trace_call );
  tracestmt->push_back( stophere );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_exec_and_stop( BPatch_snippet * s )
{
  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;

  tracestmt->push_back( s );
  tracestmt->push_back( stophere );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_while_snippet( BPatch_snippet * conditional,
				    BPatch_snippet * body )
{
  if( ( conditional == 0 )
      ||
      ( body == 0 ) )
    {
      return 0;
    }

  //  BPatch_nullExpr * label_done = ;

  //  BPatch_ifExpr * 

  return 0;
}
