/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <set>
#include <map>
#include <stack>
#include <algorithm>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"
#include "inserters.h"
#include "generate_trace_snippet.h"
#include "incremental_tracer.h"
#include "util.h"
#include "commands.h"
#include "snippet_library.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void sighandler      ( int );
void final_cleanup   ();
// bool is_selected     ( BPatch_Vector<BPatch_function * > & function_list,
// 		       char * name );
int  fcn_idx         ( char * name );
void run_tracer      ();
void remove_snippets ( snippethandle_map_type & snippet_map );
void remove_snippets ( snippethandle_set_type & snippet_set );
void error_callback  ( BPatchErrorLevel severity,
		       int number,
		       const char ** params );
void initialize      ( int argc,
		       char ** argv );
void read_exclusions ();
void read_preferred  ();

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_variableExpr *                level_var = 0;
BPatch_variableExpr *                trace_flag = 0;

BPatch                               bpatch;

BPatch_snippet *                     global = 0;
BPatch_variableExpr *                fooCounter;

BPatch_image *                       appImage;
BPatch_thread *                      appThread;

char                                 pipe_name[ 1024 + 1 ];
char *                               log_file_name;
int                                  fd = -1;

BPatch_Vector<BPatch_function * > *  functions = 0;

string_set_type                      exclusions;
string_set_type                      preferred;

map<int, snippethandle_set_type >    snippets_at_beginning_of;
map<int, snippethandle_set_type >    snippets_at_end_of;
map<int, snippethandle_map_type >    snippets_before_call_in;
map<int, snippethandle_map_type >    snippets_after_call_in;

map<int, snippethandle_set_type >    break_entry_snippets;
map<int, snippethandle_set_type >    break_exit_snippets;

BPatch_procedureLocation             stopped_at_point;
string                               stopped_at_function;

string_set_type                      trace_selections;

char * help_instructions[] = {
                               "trace all",
			       "trace none",
			       "trace to <function> ",
			       "trace from <function> ",
			       "trace function <function>",
			       "trace preferred",
			       "trace exclusions",
			       "trace into module <module>",
                               "don't trace all",
			       "don't trace none",
			       "don't trace to <function> ",
			       "don't trace from <function> ",
			       "don't trace function <function>",
			       "don't trace preferred",
			       "don't trace exclusions",
			       "don't trace into module <module>",
			       "show trace selections",
			       "show trace exclusions",
			       "show trace preferred",
			       "show breakpoints",
			       "detach",
			       "print return value as <format>",
			       "print argument <n> as <format>",
			       "continue",
			       "break before call to <function>",
			       "break after call to <function>",
			       "break on entry to <function>",
			       "break on exit from <function>",
			       "don't break before call to <function>",
			       "don't break after call to <function>",
			       "don't break on entry to <function>",
			       "don't break on exit from <function>",
			       "replace function <old function> with <new function>",
			       "replace calls <caller>:<old function> with <new function>",
			       "replace call <caller>:<n> with <new function>",
			       "list modules",
			       "list module <module>",
			       "list all",
			       "list functions <regexp>",
			       "list function <function> calls",
			       "list function <function> callers",
			       "load library <library>",
			       "load snippet library <snippet library>",
			       "help <command>",
			       "quit"
                             };

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

int main( int argc, char ** argv )
{
  initialize( argc, argv );

  bool done = false;
  char prompt[ 80 + 1 ];
  strcpy( prompt, "dynit> " );

  while( ! done )
    {
      char line[ 256 + 1 ];
      cout << prompt; cout.flush();
      cin.getline( line, 256 );

      if( strcmp( line, "exit" ) == 0 )
	{
	  done = true;
	}
      else if( strcmp( line, "quit" ) == 0 )
	{
	  done = true;
	}
      else if( strcmp( line, "" ) == 0 )
	{
	}
      else if( strstr( line, "list" ) == line )
	{
	  do_list_command( line );
	}
      else if( strcmp( line, "continue" ) == 0 )
	{
	  cout << "=- Continuing the process..." << endl;
	  run_tracer();
	  done = appThread->isTerminated();
	}
      else if( strstr( line, "load library " ) == line )
	{
	  char * library_name = line + 13;
	  if( appThread->loadLibrary( library_name ) )
	    {
	      cout << "=- Library '" << library_name
		   << "' was successfully loaded in the mutatee." << endl;
	    }
	  else
	    {
	      cout << "=- Library '" << library_name
		   << "' could not be loaded in the mutatee." << endl;
	    }
	}
      else if( strstr( line, "trace " ) == line )
	{
	  cout << "=- 'trace' not yet implemented." << endl;
	}
      else if( strstr( line, "don't trace " ) == line )
	{
	  cout << "=- 'don't trace' not yet implemented." << endl;
	}
      else if( strstr( line, "print " ) == line )
	{
	  if( strstr( line, "print return value as " ) == line )
	    {
	      if( stopped_at_point != BPatch_exit )
		{
		  cout << "=- ERROR: return values can be printed only"
		       << " when stopped at function exit." << endl;
		}
	      else
		{
		  char * format = line + 22;

		  BPatch_function * function = appImage->findFunction( stopped_at_function.data() );

		  BPatch_snippet * snippet =
		    gen_exec_and_stop( gen_trace_formatted_value_snippet( appThread, pipe_name,
									  format,
									  new BPatch_retExpr() ) );

		  snippethandle_set_type & snippet_set =
		    insert_at_exit_points( function, snippet );

		  run_tracer();

		  remove_snippets( snippet_set );
		  delete & snippet_set;
		}
	    }
	  else
	    {
	      cout << "=- 'print' not yet implemented." << endl;
	    }
	}
      else if( strstr( line, "break" ) == line )
	{
	  do_break_command( line );
	}
      else if( strstr( line, "don't break" ) == line )
	{
	  cout << "=- 'don't break' not yet implemented." << endl;
	}
      else if( strstr( line, "replace " ) == line )
	{
	  do_replace_command( line );
	}
      else if( strstr( line, "unreplace " ) == line )
	{
	  cout << "=- 'unreplace' not yet implemented." << endl;
	}
      else if( strstr( line, "load snippetlibrary " ) == line )
	{
	  cout << "=- 'load snippetlibrary' not yet implemented." << endl;
	}
      else if( strstr( line, "insert snippet " ) == line )
	{
	  cout << "=- 'insert snippet' not yet implemented." << endl;
	}
      else if( strstr( line, "show " ) == line )
	{
	  do_show_command( line );
	}
      else if( strcmp( line, "detach" ) == 0 )
	{
	  for( int i = 0; i < functions->size(); i++ )
	    {
	      remove_snippets( snippets_at_beginning_of[ i ] );
	      snippets_at_beginning_of[ i ].clear();

	      remove_snippets( snippets_at_end_of[ i ] );
	      snippets_at_end_of[ i ].clear();

	      remove_snippets( snippets_before_call_in[ i ] );
	      snippets_before_call_in[ i ].clear();

	      remove_snippets( snippets_after_call_in[ i ] );
	      snippets_after_call_in[ i ].clear();
	    }

	  cout << "=- Detached from process." << endl;
	}
      else if( strstr( line, "help" ) == line )
	{
	  char * info = line + 5;

	  if( info >= line + strlen( line ) )
	    {
	      cout << "Help:" << endl
		   << "  help <command>" << endl;
	    }
	  else
	    {
	      bool found = false;
	      for( unsigned int i = 0;
		   i < sizeof( help_instructions ) / sizeof( char * );
		   i++ )
		{
		  if( strstr( help_instructions[ i ], info ) == help_instructions[ i ] )
		    {
		      if( ! found )
			{
			  found = true;
			  cout << "Help:" << endl;
			}
		      cout << "  " << help_instructions[ i ] << endl;
		    }
		}
	      if( ! found )
		{
		  cout << "No help found on '" << info << "'." << endl;
		}
	    }
	}

      free( line );
    }

  appThread->terminateExecution();
  cout << "=- The process has ended." << endl;

  final_cleanup();

  return 0;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void error_callback( BPatchErrorLevel severity, int number, const char ** params )
{
  char buffer[ 1024 + 1 ];
  BPatch::formatErrorString( buffer, 1024, BPatch::getEnglishErrorString( number ), params );

  switch( severity )
    {
    case BPatchFatal: cout << "=- DynInst: FATAL: "; break;
    case BPatchSerious: cout << "=- DynInst: SERIOUS: "; break;
    case BPatchWarning: return; /* cout << "WARNING: "; break; */
    case BPatchInfo: return; /* cout << "INFO: "; break; */
    }

  cout << buffer << "." << endl;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void read_exclusions()
{
  ifstream fin;
  fin.open( "exclusions.txt" );
  if( ! fin.fail() )
    {
      char s[ 1024 + 1 ];
      while( fin >> s )
	{
	  exclusions.insert( string( s ) );
	}
    }
  fin.close();

  cout << "=- Read exclusions.txt: " << exclusions.size() << " function names." << endl;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void read_preferred()
{
  ifstream fin;
  fin.open( "preferred.txt" );
  if( ! fin.fail() )
    {
      char s[ 1024 + 1 ];
      while( fin >> s )
	{
	  preferred.insert( string( s ) );
	}
    }
  fin.close();

  cout << "=- Read preferred.txt: " << preferred.size() << " function names." << endl;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

char * get_unique_temp_name()
{
  char str_template[ 1024 + 1 ];
  strcpy( str_template, "iTXXXXXX" );

  return mktemp( str_template );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_function * get_void_fill_in()
{
  char * fcnname = "void_fill_in";

  static BPatch_function * fcn = 0;

  if( fcn == 0 )
    {
      fcn = appImage->findFunction( fcnname );
      if( fcn == 0 )
	{
	  appThread->loadLibrary( "libcool_trace.so" );
	  fcn = appImage->findFunction( fcnname );
	}
    }

  return fcn;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void process_removals()
{
  map<char *, char *> call;

  {
    ifstream fin;
    fin.open( "removed.txt" );
    if( fin.fail() )
      {
	return;
      }

    char line[ 1024 + 1 ];
    while( fin.getline( line, 1024 ) )
      {
	char * marker = strstr( line, ":" );
	* marker = '\0';

	char * caller = line;
	char * callee = marker + 1;

	call[ strdup( caller ) ] = strdup( callee );
      }
    fin.close();
  }

  for( int i = 0; i < functions->size(); i++ )
    {
      BPatch_function * function = ( * functions )[ i ];

      if( ! function )
	{
	  continue;
	}

      char * t_funcname = new char[ 1024 + 1 ];
      function->getName( t_funcname, 1024 );
      char * funcname = new char[ strlen( t_funcname ) + 1 ];
      strcpy( funcname, t_funcname );
      delete t_funcname;

      BPatch_Vector<BPatch_point * > & call_points =
	* function->findPoint( BPatch_subroutine );

      char function_name[ 1024 + 1 ];
      function->getName( function_name, 1024 );

      for( int j = 0; j < call_points.size(); j++ )
	{
	  if( call_points[ j ] == 0 )
	    {
	      continue;
	    }

	  if( call_points[ j ]->getCalledFunction() == 0 )
	    {
	      continue;
	    }

	  char subname[ 1024 + 1 ];
	  call_points[ j ]->getCalledFunction()->getName( subname, 1024 );

	  for( map<char *, char *>::iterator index = call.begin();
	       index != call.end();
	       index++ )
	    {
	      if( ( strcmp( funcname, index->first ) == 0 )
		  &&
		  ( strcmp( subname, index->second ) == 0 ) )
		{
		  if( appThread->replaceFunctionCall( * call_points[ j ], * get_void_fill_in() ) )
		    {
		      cout << "=- Call in " << funcname << " to "
			   << subname << " replaced." << endl;
		    }
		  else
		    {
		      cout << "=- ERROR: Cannot replace call in "
			   << funcname << " to " << subname << "!" << endl;
		    }
		}
	    }
	}
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void initialize( int argc, char ** argv )
{
  assert( argc != 0 );

  read_exclusions();
  read_preferred();

  log_file_name = get_unique_temp_name();
  sprintf( pipe_name, "%s.pipe", log_file_name );
  if( mkfifo( pipe_name, 0777 ) != 0 )
    {
      cout << "=- Failed to create the FIFO file. Eject, eject..." << endl;
      appThread->terminateExecution();
      final_cleanup();
      exit( 1 );
    }

  bpatch.registerErrorCallback( ( BPatchErrorCallback )error_callback );

  signal( SIGSEGV, sighandler);
  signal( SIGKILL, sighandler);
  signal( SIGINT, sighandler );

  cout << "=- Creating process " << argv[ 1 ] << " ... "; cout.flush();
  appThread = bpatch.createProcess( argv[ 1 ], argv + 1 );
  cout << "done." << endl;
  if( ! appThread )
    {
      cout << "=- Couldn't create process!" << endl;
      exit( -1 );
    }
  cout << "=- Process pid " << appThread->getPid() << "." << endl;
  appImage = appThread->getImage();

  functions = appImage->getProcedures();

  get_core_functions( appImage );

  fd = open( pipe_name, O_RDONLY );

  for( int i = 0; i < functions->size(); i++ )
    {
      snippets_at_beginning_of[ i ].clear();
      snippets_at_end_of[ i ].clear();
      snippets_before_call_in[ i ].clear();
      snippets_after_call_in[ i ].clear();
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void sighandler( int sig )
{
  fprintf( stderr,"\n\n=- Received signal %d: terminating...\n", sig );

  appThread->terminateExecution();

  final_cleanup();

  exit( 0 );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void final_cleanup()
{
  if( fd != -1 )
    {
      close( fd );
    }
  unlink( pipe_name );

  struct stat buf;

  if( stat( "./core", & buf ) == 0 )
    {
      char response;

      cout << "=- A core-file was generated. Do you want to delete it? [y/n] ";
      cin >> response;
      if( ( response == 'y' ) || ( response == 'Y' ) )
	{
	  unlink( "./core" );
	}
    }

  delete appThread;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

// bool is_selected_for_trace( char * name )
// {
//   if( strcmp( name, "trace_to_file" ) == 0 )
//     {
//       return false;
//     }

//   bool found =
//     find( traced_functions.begin(), traced_functions.end(), string( name ) )
//     !=
//     traced_functions.end();

//   return found;
// }

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

int fcn_idx( char * name )
{

  if( functions != 0 )
    {
      for( int i = 0; i < functions->size(); i++ )
	{
	  BPatch_function * fcn = ( * functions )[ i ];
	  if( fcn != 0 )
	    {
	      char fcn_name[ 1024 ];
	      fcn->getName( fcn_name, 1024 );
	      if( strcmp( name, fcn_name ) == 0 )
		{
		  return i;
		}
	    }
	}
    }

  return -1;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void remove_snippets( snippethandle_set_type & snippet_set )
{
  for( snippethandle_set_type::iterator index = snippet_set.begin();
       index != snippet_set.end();
       index++ )
    {
      if( * index != 0 )
	{
	  appThread->deleteSnippet( * index );
	}
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void remove_snippets( snippethandle_map_type & snippet_map )
{
  for( snippethandle_map_type::iterator index = snippet_map.begin();
       index != snippet_map.end();
       index++ )
    {
      if( index->second != 0 )
	{
	  appThread->deleteSnippet( index->second );
	}
    }
}
