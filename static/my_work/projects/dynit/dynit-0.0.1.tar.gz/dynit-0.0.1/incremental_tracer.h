#ifndef _Incremental_Tracer_h_

#define _Incremental_Tracer_h_

void run_tracer();

#endif
