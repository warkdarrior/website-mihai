/* util.h
 *
 * intended to have some cool utility functions for our
 * dynInst crap...
 *
 * Rob
 */

#ifndef _UTIL_H_
#define _UTIL_H_


#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

#include <assert.h>
#include <stdio.h>

typedef BPatch_Vector<BPatch_function*> _funcvec;

BPatch_module * findModule(BPatch_image *image, const char *name );

_funcvec * get_core_functions(BPatch_image *image);

void list_modules(BPatch_image *image);

void list_funcs_by_module(BPatch_image *image);


void break_on_function(BPatch_image *, const char* name);

void trim_functions(_funcvec *fvec, char* regexp);
void remove_functions(_funcvec *fvec, char *regexp);
void addremove_functions(_funcvec *f, char *r, bool r);

set<char *> & get_matching_function_names ( BPatch_image * appImage,
					    char * regexp_string );
set<char *> & get_function_callers        ( BPatch_image * appImage,
					    char * function_name );

#endif
