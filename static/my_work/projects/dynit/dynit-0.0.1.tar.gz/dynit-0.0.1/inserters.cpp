/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <string.h>
#include <math.h>
#include <libgen.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <string>
#include <iostream>
#include <iomanip>
#include <set>
#include <map>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"
#include "snippet_library.h"
#include "inserters.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

snippethandle_set_type & insert_at_entry_points( BPatch_function * function,
						 BPatch_snippet * snippet )
{
  snippethandle_set_type & point_set = * new snippethandle_set_type;

  BPatch_Vector<BPatch_point * > * entry_points = function->findPoint( BPatch_entry );

  for( int j = 0; j < entry_points->size(); j++ )
    {
      if( ( * entry_points )[ j ] == 0 )
	{
	  continue;
	}

      BPatch_point * insertion_point = ( * entry_points )[ j ];

      BPatchSnippetHandle * handle =
	appThread->insertSnippet( * snippet, * insertion_point,
				  BPatch_callAfter, BPatch_lastSnippet );

      if( handle == 0 )
	{
	  cout << "=- ERROR: Failed to insert." << endl;
	}
      else
	{
	  point_set.insert( handle );
	}
    }

  return point_set;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

set<BPatchSnippetHandle *> & insert_at_exit_points( BPatch_function * function,
						    BPatch_snippet * snippet )
{
  set<BPatchSnippetHandle *> & point_set = * new set<BPatchSnippetHandle *>;

  BPatch_Vector<BPatch_point * > * exit_points = function->findPoint( BPatch_exit );

  for( int j = 0; j < exit_points->size(); j++ )
    {
      if( ( * exit_points )[ j ] == 0 )
	{
	  continue;
	}

      BPatch_point * insertion_point = ( * exit_points )[ j ];

      BPatchSnippetHandle * handle =
	appThread->insertSnippet( * snippet, * insertion_point,
				  BPatch_callBefore, BPatch_lastSnippet );

      if( handle == 0 )
	{
	  cout << "=- ERROR: Failed to insert." << endl;
	}
      else
	{
	  point_set.insert( handle );
	}
    }

  return point_set;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

map<int, BPatchSnippetHandle *> & insert_before_calls( BPatch_function * function )
{
  map<int, BPatchSnippetHandle *> & point_map =
    * new map<int, BPatchSnippetHandle *>;

  if( function == 0 )
    {
      return point_map;
    }

  BPatch_Vector<BPatch_point * > & call_points =
    * function->findPoint( BPatch_subroutine );

  char function_name[ 1024 + 1 ];
  function->getName( function_name, 1024 );

  for( int j = 0; j < call_points.size(); j++ )
    {
      if( call_points[ j ] == 0 )
	{
	  continue;
	}

      if( call_points[ j ]->getCalledFunction() == 0 )
	{
	  continue;
	}

      char subname[ 1024 + 1 ];
      call_points[ j ]->getCalledFunction()->getName( subname, 1024 );

      char msg[ strlen( function_name ) + 1 + strlen( subname ) + 1 + 5 + 1 ];
      sprintf( msg, "%s:%d:%s", function_name, j, subname );

      BPatch_snippet * snippet =
	gen_before_snippet( appThread, pipe_name, msg );

      BPatchSnippetHandle * result =
	appThread->insertSnippet( * snippet, * call_points[ j ], BPatch_callBefore );

      if( result == 0 )
	{
	  cout << "=- ERROR: failed to insert before snippet." << endl;
	}
      else
	{
	  point_map[ j ] = result;
	}
    }

  return point_map;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

map<int, BPatchSnippetHandle *> & insert_after_calls( BPatch_function * function )
{
  map<int, BPatchSnippetHandle *> & point_map =
    * new map<int, BPatchSnippetHandle *>;

  if( function == 0 )
    {
      return point_map;
    }

  BPatch_Vector<BPatch_point * > & call_points =
    * function->findPoint( BPatch_subroutine );

  char function_name[ 1024 + 1 ];
  function->getName( function_name, 1024 );

  for( int j = 0; j < call_points.size(); j++ )
    {
      if( call_points[ j ] == 0 )
	{
	  continue;
	}
      if( call_points[ j ]->getCalledFunction() == 0 )
	{
	  continue;
	}

      char subname[ 1024 + 1 ];
      call_points[ j ]->getCalledFunction()->getName( subname, 1024 );

      char msg[ strlen( function_name ) + 1 + 5 + strlen( subname ) + 1 + 1 ];
      sprintf( msg, "%s:%d:%s", function_name, j, subname );

      BPatch_snippet * snippet =
	gen_after_snippet( appThread, pipe_name, msg );

      BPatchSnippetHandle * result =
	appThread->insertSnippet( * snippet, * call_points[ j ], BPatch_callAfter );

      if( result == 0 )
	{
	  cout << "=- ERROR: failed to insert after snippet." << endl;
	}
      else
	{
	  point_map[ j ] = result;
	}
    }

  return point_map;
}
