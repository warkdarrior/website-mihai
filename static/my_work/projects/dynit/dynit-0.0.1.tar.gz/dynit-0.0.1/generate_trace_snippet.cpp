#include "BPatch.h"
#include "BPatch_Vector.h"
#include "BPatch_image.h"
#include "BPatch_module.h"
#include "BPatch_point.h"
#include "BPatch_snippet.h"
#include "BPatch_thread.h"
#include "BPatch_type.h"

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <iostream>
using namespace std;

BPatch_snippet * gen_trace_snippet( BPatch_thread * app_thread,
				    char * trace_file,
				    char * trace_msg )
{

  assert( trace_file != 0 );
  assert( trace_msg != 0 );

  BPatch_image * app_image = app_thread->getImage();

  char * line_of_text = new char[ strlen( trace_msg ) + 2 ];
  sprintf( line_of_text, "%s\n", trace_msg );

  static BPatch_variableExpr * fd_var = 0;
  if( fd_var == 0 )
    {
      fd_var = app_thread->malloc( * app_image->findType( "int" ) );
    }

  BPatch_constExpr * openarg_filename =
    new BPatch_constExpr( trace_file );
  BPatch_constExpr * openarg_fileflags =
    new BPatch_constExpr( O_WRONLY | O_APPEND | O_CREAT );
  BPatch_constExpr * openarg_filemode =
    new BPatch_constExpr( 0600 );
  BPatch_Vector<BPatch_snippet *> * openargs =
    new BPatch_Vector<BPatch_snippet *>;
  openargs->push_back( openarg_filename );
  openargs->push_back( openarg_fileflags );
  openargs->push_back( openarg_filemode );

  BPatch_function * openfunc = app_image->findFunction( "open" );
  BPatch_funcCallExpr * opencall =
    new BPatch_funcCallExpr( * openfunc, * openargs );

  BPatch_arithExpr * openstmt =
    new BPatch_arithExpr( BPatch_assign, * fd_var, * opencall );

  BPatch_constExpr * writearg_buf =
    new BPatch_constExpr( line_of_text );
  BPatch_constExpr * writearg_nbytes =
    new BPatch_constExpr( strlen( line_of_text ) );
  BPatch_Vector<BPatch_snippet *> * writeargs =
    new BPatch_Vector<BPatch_snippet *>;
  writeargs->push_back( fd_var );
  writeargs->push_back( writearg_buf );
  writeargs->push_back( writearg_nbytes );

  BPatch_function * writefunc = app_image->findFunction( "write" );
  BPatch_funcCallExpr * writecall =
    new BPatch_funcCallExpr( * writefunc, * writeargs );

  BPatch_Vector<BPatch_snippet *> * closeargs =
    new BPatch_Vector<BPatch_snippet *>;
  closeargs->push_back( fd_var );

  BPatch_function * closefunc = app_image->findFunction( "close" );
  BPatch_funcCallExpr * closecall =
    new BPatch_funcCallExpr( * closefunc, * closeargs );

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;
  tracestmt->push_back( openstmt );
  tracestmt->push_back( writecall );
  tracestmt->push_back( closecall );

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_snippet * return_value = traceseq;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

extern BPatch_variableExpr * level_var;
extern BPatch_variableExpr * trace_flag;

BPatch_snippet * gen_cool_trace_snippet( BPatch_thread * app_thread,
					 char * trace_file,
					 char * trace_msg,
					 bool end_of_func )
{

  char * trace_func_name = "trace_to_file";

  assert( trace_file != 0 );
  assert( trace_msg != 0 );

  BPatch_image * app_image = app_thread->getImage();

  if( level_var == 0 )
    {
      cerr << "gen_cool_trace_snippet: ";
      cerr << "Allocating the level_var variable...";
      level_var = app_thread->malloc( * app_image->findType( "int" ) );
      cerr << " done.";
      cerr << endl; cerr.flush();
      assert( level_var != 0 );
    }

  if( trace_flag == 0 )
    {
      cerr << "gen_cool_trace_snippet: ";
      cerr << "Allocating the trace_flag variable...";
      trace_flag = app_thread->malloc( * app_image->findType( "int" ) );
      cerr << " done.";
      cerr << endl; cerr.flush();
      assert( trace_flag != 0 );
    }

  assert( level_var != 0 );
  assert( trace_flag != 0 );

  int delta = ( end_of_func ? -1 : 1 );
  /*
    cerr << "Instrumenting " << ( end_of_func ? "the end of " : "the beginning of " )
    << trace_msg << " (level will be "
    << ( delta == -1 ? "incremented)." : "decremented)." );
    cerr << endl; cerr.flush();
  */

  BPatch_arithExpr * disabletrace =
    new BPatch_arithExpr( BPatch_assign, * trace_flag, BPatch_constExpr( 0 ) );

  BPatch_constExpr * cooltracearg_filename =
    new BPatch_constExpr( trace_file );
  BPatch_constExpr * cooltracearg_message =
    new BPatch_constExpr( trace_msg );
  BPatch_Vector<BPatch_snippet *> * cooltraceargs =
    new BPatch_Vector<BPatch_snippet *>;
  // cooltraceargs->push_back( level_var );
  cooltraceargs->push_back( cooltracearg_filename );
  cooltraceargs->push_back( cooltracearg_message );
  // cooltraceargs->push_back( trace_flag );
  cooltraceargs->push_back( new BPatch_constExpr( end_of_func ? 1 : 0 ) );

  BPatch_function * cooltracefunc = app_image->findFunction( trace_func_name );
  if( cooltracefunc == 0 )
    {
      char * library_name = "libcool_trace.so";
      cerr << "gen_cool_trace_snippet: ";
      cerr << "Loading the " << library_name << " library...";
      app_thread->loadLibrary( library_name );
      cerr << " done." << endl; cerr.flush();
      cooltracefunc = app_image->findFunction( trace_func_name );
      assert( cooltracefunc != 0 );
    }
  BPatch_funcCallExpr * cooltracecall =
    new BPatch_funcCallExpr( * cooltracefunc, * cooltraceargs );

  BPatch_arithExpr * enabletrace =
    new BPatch_arithExpr( BPatch_assign, * trace_flag, BPatch_constExpr( 1 ) );

  BPatch_constExpr * value = new BPatch_constExpr( delta );
  BPatch_arithExpr * modifylevel = new BPatch_arithExpr( BPatch_assign,
							 * level_var,
							 BPatch_arithExpr( BPatch_plus,
									   * level_var,
									   * value
									   )
							 );

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;
  if( ! end_of_func )
    {
      tracestmt->push_front( modifylevel ); // ++
      tracestmt->push_back( disabletrace );
      tracestmt->push_back( cooltracecall );
      tracestmt->push_back( enabletrace );
    }
  else
    {
      tracestmt->push_back( modifylevel ); // --
    }

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_boolExpr * traceenabled =
    new BPatch_boolExpr( BPatch_eq, * trace_flag, BPatch_constExpr( 1 ) );

  BPatch_ifExpr * iftraceenabled =
    new BPatch_ifExpr( * traceenabled, * traceseq );

  BPatch_snippet * return_value = iftraceenabled;

  return return_value;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_snippet * gen_trace_and_stop_snippet( BPatch_thread * app_thread,
					     char * trace_file,
					     char * trace_msg,
					     bool end_of_func
					     )
{
  char * trace_func_name = "piped_trace";

  assert( trace_file != 0 );
  assert( trace_msg != 0 );

  BPatch_image * app_image = app_thread->getImage();

  if( level_var == 0 )
    {
      cerr << "gen_trace_and_stop_snippet: ";
      cerr << "Allocating the level_var variable...";
      level_var = app_thread->malloc( * app_image->findType( "int" ) );
      cerr << " done.";
      cerr << endl; cerr.flush();
      assert( level_var != 0 );
    }

  if( trace_flag == 0 )
    {
      cerr << "gen_trace_and_stop_snippet: ";
      cerr << "Allocating the trace_flag variable...";
      trace_flag = app_thread->malloc( * app_image->findType( "int" ) );
      cerr << " done.";
      cerr << endl; cerr.flush();
      assert( trace_flag != 0 );
    }

  assert( level_var != 0 );
  assert( trace_flag != 0 );

  int delta = ( end_of_func ? -1 : 1 );
  cerr << "Instrumenting " << ( end_of_func ? "the end of " : "the beginning of " )
       << trace_msg << " (level will be "
       << ( delta == 1 ? "incremented)." : "decremented)." );
  cerr << endl; cerr.flush();

  BPatch_constExpr * cooltrace2arg_filename =
    new BPatch_constExpr( trace_file );
  BPatch_constExpr * cooltrace2arg_message =
    new BPatch_constExpr( trace_msg );
  BPatch_Vector<BPatch_snippet *> * cooltrace2args =
    new BPatch_Vector<BPatch_snippet *>;
  cooltrace2args->push_back( level_var );
  cooltrace2args->push_back( cooltrace2arg_filename );
  cooltrace2args->push_back( cooltrace2arg_message );
  cooltrace2args->push_back( new BPatch_constExpr( ( end_of_func ) ? 1 : 0 ) );

  BPatch_function * cooltrace2func = app_image->findFunction( trace_func_name );
  if( cooltrace2func == 0 )
    {
      char * library_name = "libcool_trace.so";
      cerr << "gen_trace_and_stop_snippet: ";
      cerr << "Loading the " << library_name << " library...";
      app_thread->loadLibrary( library_name );
      cerr << " done." << endl; cerr.flush();
      cooltrace2func = app_image->findFunction( trace_func_name );
      assert( cooltrace2func != 0 );
    }
  BPatch_funcCallExpr * cooltrace2call =
    new BPatch_funcCallExpr( * cooltrace2func, * cooltrace2args );

  BPatch_constExpr * value = new BPatch_constExpr( delta );
  BPatch_arithExpr * modifylevel = new BPatch_arithExpr( BPatch_assign,
							 * level_var,
							 BPatch_arithExpr( BPatch_plus,
									   * level_var,
									   * value
									   )
							 );

  BPatch_breakPointExpr * stophere = new BPatch_breakPointExpr();

  BPatch_Vector<BPatch_snippet *> * tracestmt =
    new BPatch_Vector<BPatch_snippet *>;
  if( ! end_of_func )
    {
      tracestmt->push_front( modifylevel );
      tracestmt->push_back( cooltrace2call );

      tracestmt->push_back( stophere );
    }
  else
    {
      tracestmt->push_back( modifylevel );
      tracestmt->push_back( modifylevel );
      tracestmt->push_back( cooltrace2call );

      tracestmt->push_back( stophere );
    }

  BPatch_sequence * traceseq = new BPatch_sequence( * tracestmt );

  BPatch_boolExpr * traceenabled =
    new BPatch_boolExpr( BPatch_eq, * trace_flag, BPatch_constExpr( 1 ) );

  BPatch_ifExpr * iftraceenabled =
    new BPatch_ifExpr( * traceenabled, * traceseq );

  BPatch_snippet * return_value = iftraceenabled;

  return return_value;
}
