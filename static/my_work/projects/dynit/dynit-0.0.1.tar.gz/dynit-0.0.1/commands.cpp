/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <string.h>
#include <math.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <string>
#include <iostream>
#include <iomanip>
#include <set>
#include <map>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"
#include "commands.h"
#include "inserters.h"
#include "incremental_tracer.h"
#include "util.h"
#include "snippet_library.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void print_module_names           ();
void print_module_functions       ( char * module_name );
void _do_list_function_command    ( char * command );
void print_function_calls         ( char * function_name );
void _do_replace_calls_command    ( char * command );
void _do_replace_function_command ( char * command );

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void do_list_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  if( strstr( command, "list functions " ) == command )
    {
      char * regexp_string = command + 15;
      if( regexp_string >= ( command + strlen( command ) ) ) { return; }

      set<char *> & matched_set =
	get_matching_function_names( appImage, regexp_string );

      if( matched_set.size() > 0 )
	{
	  cout << matched_set.size() << " function"
	       << ( matched_set.size() == 1 ? " matches " : "s match " )
	       << "the regular expression '" << regexp_string << "':" << endl;
	  for( set<char *>::iterator index = matched_set.begin();
	       index != matched_set.end();
	       index++ )
	    {
	      cout << "  " << * index << endl;
	      free( * index );
	    }
	}
      else
	{
	  cout << "No functions match the regular expression '" << regexp_string << "':" << endl;
	}

      delete & matched_set;
    }
  else if( strstr( command, "list function " ) == command )
    {
      _do_list_function_command( command );
    }
  else if( strstr( command, "list all" ) == command )
    {
      BPatch_Vector<BPatch_module * > & module_list =
	* appImage->getModules();

      for( int i = 0; i < module_list.size(); i++ )
	{
	  bool already_printed = false;
	  char module_name[ 1024 + 1 ];

	  strcpy( module_name, "<unknown module name>" );
	  if( module_list[ i ] != 0 )
	    {
	      module_list[ i ]->getName( module_name, 1024 );

	      for( int j = 0; j < i; j++ )
		{
		  if( module_list[ j ] != 0 )
		    {
		      char other_name[ 1024 + 1 ];
		      module_list[ j ]->getName( other_name, 1024 );

		      if( strcmp( other_name, module_name ) == 0 )
			{
			  already_printed = true;
			}
		    }
		}
	    }

	  if( ! already_printed )
	    {
	      print_module_functions( module_name );
	    }
	}
    }
  else if( strstr( command, "list module " ) == command )
    {
      print_module_functions( command + 12 );
    }
  else if( strcmp( command, "list modules" ) == 0 )
    {
      print_module_names();
    }
  else
    {
      cout << "=- ERROR: 'list' command parameter missing." << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void print_module_names()
{
  BPatch_Vector<BPatch_module * > & module_list =
    * appImage->getModules();

  for( int i = 0; i < module_list.size(); i++ )
    {
      bool already_printed = false;
      char module_name[ 1024 + 1 ];

      strcpy( module_name, "<unknown module name>" );
      if( module_list[ i ] != 0 )
	{
	  module_list[ i ]->getName( module_name, 1024 );

	  for( int j = 0; j < i; j++ )
	    {
	      if( module_list[ j ] != 0 )
		{
		  char other_name[ 1024 + 1 ];
		  module_list[ j ]->getName( other_name, 1024 );

		  if( strcmp( other_name, module_name ) == 0 )
		    {
		      already_printed = true;
		    }
		}
	    }
	}

      if( ! already_printed )
	{
	  cout << module_name << endl;
	}
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void print_module_functions( char * module_name )
{
  if( module_name == 0 )
    {
      return;
    }

  BPatch_module * module = findModule( appImage, module_name );

  if( module == 0 )
    {
      cout << "=- Module '" << module_name << "' not found." << endl;
    }
  else
    {
      BPatch_Vector<BPatch_function * > & function_list
	= * module->getProcedures();

      cout << "Module '" << module_name << "': " << function_list.size()
	   << " function" << ( function_list.size() == 1 ? "" : "s" ) << endl;

      for( int i = 0; i < function_list.size(); i++ )
	{
	  char function_name[ 1024 + 1 ];

	  strcpy( function_name, "<unknown function name>" );
	  if( function_list[ i ] != 0 )
	    {
	      function_list[ i ]->getName( function_name, 1024 );
	    }

	  cout << "   " << function_name << endl;
	}
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void _do_list_function_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  char * p1, * p2;

  p1 = command + 14;
  if( p1 >= ( command + strlen( command ) ) )
    { cout << "=- ERROR: 'list function' is missing the function name." << endl; return; }
  p2 = strstr( p1, " " );
  if( p2 != 0 ) { * p2 = '\0'; }
  char function_name[ 1024 + 1 ];
  strcpy( function_name, p1 );
  if( p2 != 0 ) { * p2 = ' '; }
  if( strlen( function_name ) < 1 )
    { cout << "=- ERROR: 'list function' uses an invalid function name." << endl; return; }

  char * option = command + 14 + strlen( function_name ) + 1;
  if( option > ( command + strlen( command ) ) ) { option = command + strlen( command ); }

  if( strcmp( option, "calls" ) == 0 )
    {
      print_function_calls( function_name );
    }
  else if( strcmp( option, "callers" ) == 0 )
    {
      set<char *> & caller_set =
	get_function_callers( appImage, function_name );

      if( caller_set.size() > 0 )
	{
	  cout << "Function '" << function_name << "' is called by "
	       << caller_set.size() << " function" << ( caller_set.size() == 1 ? "" : "s" )
	       << ":" << endl;
	  for( set<char *>::iterator index = caller_set.begin();
	       index != caller_set.end();
	       index++ )
	    {
	      cout << "  " << * index << endl;
	      free( * index );
	    }
	}
      else
	{
	  cout << "Function '" << function_name << "' is not called from anywhere." << endl;
	}

      delete & caller_set;
    }
  else
    {
      cout << "=- ERROR: Unknown option '" << option << "' for 'list function'." << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void print_function_calls( char * function_name )
{
  BPatch_function * function =
    appImage->findFunction( function_name );

  if( function == 0 )
    {
      cout << "=- Function '" << function_name << "' not found." << endl;
      return;
    }

  BPatch_Vector<BPatch_point * > * p_call_points =
    function->findPoint( BPatch_subroutine );
  if( p_call_points == 0 )
    {
      cout << "Function '" << function_name << "' makes no calls." << endl;
      return;
    }
  if( p_call_points->size() == 0 )
    {
      cout << "Function '" << function_name << "' makes no calls." << endl;
      return;
    }
  BPatch_Vector<BPatch_point * > & call_points =
    * p_call_points;

  cout << "Function '" << function_name << "' makes "
       << call_points.size() << " calls:" << endl;
  int width = ( int )ceil( log( call_points.size() ) / log( 10 ) );
  for( int i = 0; i < call_points.size(); i++ )
    {
      char subroutine_name[ 1024 + 1 ];

      if( call_points[ i ] != 0 )
	{
	  BPatch_function * subroutine = call_points[ i ]->getCalledFunction();

	  if( subroutine == 0 )
	    {
	      strcpy( subroutine_name, "<unknown call target>" );
	    }
	  else
	    {
	      subroutine->getName( subroutine_name, 1024 );
	    }
	}
      else
	{
	  strcpy( subroutine_name, "<unknown call>" );
	}

      cout << "  " << setw( width ) << ( i + 1 ) << ". " << subroutine_name << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void do_break_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  if( strstr( command, "break before call to " ) == command )
    {
      cout << "=- 'break before call to' not yet implemented." << endl;
    }
  else if( strstr( command, "break after call to " ) == command )
    {
      cout << "=- 'break after call to' not yet implemented." << endl;
    }
  else if( strstr( command, "break on entry to " ) == command )
    {
      char * function_name = command + 18;
      if( function_name >= ( command + strlen( command ) ) )
	{
	  cout << "=- ERROR: 'break on entry to' command parameter missing." << endl;
	  return;
	}

      if( break_entry_snippets.find( fcn_idx( function_name ) )
	  !=
	  break_entry_snippets.end() )
	{
	  cout << "=- ERROR: function '" << function_name
	       << "' already has a breakpoint on entry." << endl;
	  return;
	}

      BPatch_function * function = appImage->findFunction( function_name );
      if( function == 0 )
	{
	  cout << "=- ERROR: function '" << function_name << "' not found." << endl;
	  return;
	}

      BPatch_snippet * snippet = gen_entry_snippet( appThread, pipe_name, function_name, "b:>" );

      snippethandle_set_type & result =
	insert_at_entry_points( function, snippet );

      break_entry_snippets[ fcn_idx( function_name ) ] = result;
    }
  else if( strstr( command, "break on exit from " ) == command )
    {
      char * function_name = command + 19;
      if( function_name >= ( command + strlen( command ) ) )
	{
	  cout << "=- ERROR: 'break on exit from' command parameter missing." << endl;
	  return;
	}

      if( break_exit_snippets.find( fcn_idx( function_name ) )
	  !=
	  break_exit_snippets.end() )
	{
	  cout << "=- ERROR: function '" << function_name
	       << "' already has a breakpoint on exit." << endl;
	  return;
	}

      BPatch_function * function = appImage->findFunction( function_name );
      if( function == 0 )
	{
	  cout << "=- ERROR: function '" << function_name << "' not found." << endl;
	  return;
	}

      BPatch_snippet * snippet = gen_exit_snippet( appThread, pipe_name, function_name, "b:<" );

      snippethandle_set_type & result =
	insert_at_exit_points( function, snippet );

      break_exit_snippets[ fcn_idx( function_name ) ] = result;
    }
  else
    {
      cout << "=- ERROR: 'break' command parameter missing." << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void do_trace_command( char * command )
{
  if( command == 0 )
    {
      return;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void do_show_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  if( strcmp( command, "show trace selections" ) == 0 )
    {
      cout << "Trace selections: " << trace_selections.size()
	   << ( trace_selections.size() == 1 ? " entry" : " entries" ) << endl;
      for( string_set_type::iterator index = trace_selections.begin();
	   index != trace_selections.end();
	   index++ )
	{
	  cout << "  " << * index << endl;
	}
    }
  else if( strcmp( command, "show breakpoints" ) == 0 )
    {
      cout << "=- 'show breakpoints' not yet implemented." << endl;
    }
  else if( strcmp( command, "show trace exclusions" ) == 0 )
    {
      cout << "Exclusions: " << exclusions.size() << endl;
      for( string_set_type::iterator index = exclusions.begin();
	   index != exclusions.end();
	   index++ )
	{
	  cout << "  " << * index << endl;
	}
    }
  else if( strcmp( command, "show trace preferred" ) == 0 )
    {
      cout << "Preferred: " << preferred.size() << endl;
      for( string_set_type::iterator index = preferred.begin();
	   index != preferred.end();
	   index++ )
	{
	  cout << "  " << * index << endl;
	}
    }
  else
    {
      cout << "=- Unknown 'show' command: " << command << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void do_replace_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  if( strstr( command, "replace function " ) == command )
    {
      _do_replace_function_command( command );
    }
  else if( strstr( command, "replace calls " ) == command )
    {
      _do_replace_calls_command( command );
    }
  else if( strstr( command, "replace call " ) == command )
    {
      cout << "=- 'replace call' not yet implemented." << endl;
    }
  else
    {
      cout << "=- Unknown 'replace' command : " << command << endl;
    }
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void _do_replace_calls_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  char * p;
  char * q;

  p = command + 14;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: missing <caller> argument from "
	   << "'replace calls' command." << endl;
      return;
    }
  q = strstr( p, ":" );
  if( q == 0 )
    {
      cout << "=- ERROR: missing <caller> argument from "
	   << "'replace calls' command." << endl;
      return;
    }
  * q = '\0';
  char * f1name = new char[ ( q - p ) + 1 ];
  strcpy( f1name, p ); * q = ':';

  p = q + 1;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: missing <old function> argument from "
	   << "'replace calls' command." << endl;
      delete[] f1name;
      return;
    }
  q = strstr( p, " " );
  if( q == 0 )
    {
      cout << "=- ERROR: missing <old function> argument from "
	   << "'replace calls' command." << endl;
      delete[] f1name;
      return;
    }
  * q = '\0';
  char * f2name = new char[ ( q - p ) + 1 ];
  strcpy( f2name, p ); * q = ' ';

  p = q + 1;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: incorrect syntax for 'replace calls' command." << endl;
      delete[] f1name;
      delete[] f2name;
      return;
    }
  q = strstr( p, " " );
  if( q == 0 )
    {
      cout << "=- ERROR: incorrect syntax for 'replace calls' command." << endl;
      delete[] f1name;
      delete[] f2name;
      return;
    }
  * q = '\0';
  if( strcmp( p, "with" ) != 0 )
    {
      cout << "=- ERROR: incorrect syntax for 'replace calls' command." << endl;
      delete[] f1name;
      delete[] f2name;
      return;
    }
  * q = ' ';

  p = q + 1;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: missing <new function> argument from "
	   << "'replace calls' command." << endl;
      delete[] f1name;
      delete[] f2name;
      return;
    }
  q = command + strlen( command );
  if( q == 0 )
    {
      cout << "=- ERROR: missing <new function> argument from "
	   << "'replace calls' command." << endl;
      delete[] f1name;
      delete[] f2name;
      return;
    }
  char * f3name = new char[ ( q - p ) + 1 ];
  strcpy( f3name, p );

  BPatch_function * caller_function = appImage->findFunction( f1name );

  if( caller_function == 0 )
    {
      cout << "=- ERROR: function '" << f1name << "' not found." << endl;
    }
  else
    {
      BPatch_function * new_callee = appImage->findFunction( f3name );

      if( new_callee == 0 )
	{
	  cout << "=- ERROR: function '" << f3name << "' not found." << endl;
	}
      else
	{
	  BPatch_Vector<BPatch_point * > * call_points =
	    caller_function->findPoint( BPatch_subroutine );

	  if( ( call_points == 0 )
	      ||
	      ( call_points->size() == 0 ) )
	    {
	      cout << "No calls are made inside '" << f1name << "'." << endl;
	    }
	  else
	    {
	      int count = 0;
	      int succeeded = 0;
	      for( int i = 0; i < call_points->size(); i++ )
		{
		  BPatch_point * point = ( * call_points )[ i ];

		  if( point != 0 )
		    {
		      BPatch_function * callee = point->getCalledFunction();

		      if( callee != 0 )
			{
			  char callee_name[ 1024 + 1 ];
			  callee->getName( callee_name, 1024 );

			  if( strcmp( callee_name, f2name ) == 0 )
			    {
			      count++;

			      bool ok = appThread->replaceFunctionCall( * point, * new_callee );
			      if( ok )
				{
				  succeeded++;
				}
			    }
			}
		    }
		}

	      if( count == 0 )
		{
		  cout << "=- No calls to '" << f2name
		       << "' are made inside '" << f1name << "'." << endl;
		}
	      else
		{
		  cout << "=- '" << f1name << "' makes " << count << " calls to "
		       << "'" << f2name << "'." << endl
		       << "=- " << succeeded << " of these calls were replaced with calls to "
		       << "'" << f3name << "'." << endl;
		}
	    }
	}
    }

  delete[] f1name;
  delete[] f2name;
  delete[] f3name;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void _do_replace_function_command( char * command )
{
  if( command == 0 )
    {
      return;
    }

  char * p;
  char * q;

  p = command + 17;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: missing argument <old function> from "
	   << "'replace function' command." << endl;
      return;
    }
  q = strstr( p, " " );
  if( q == 0 )
    {
      cout << "=- ERROR: missing argument <old function> from "
	   << "'replace function' command." << endl;
      return;
    }
  char * f1name = new char[ ( q - p ) + 1 ]; * q = '\0';
  strcpy( f1name, p ); * q = ' ';

  p = q + 1;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: incorrect syntax for 'replace function' command." << endl;
      delete[] f1name;
      return;
    }
  q = strstr( p, " " );
  if( q == 0 )
    {
      cout << "=- ERROR: incorrect syntax for 'replace function' command." << endl;
      delete[] f1name;
      return;
    }
  * q = '\0';
  if( strcmp( p, "with" ) != 0 )
    {
      cout << "=- ERROR: incorrect syntax for 'replace function' command." << endl;
      delete[] f1name;
      return;
    }
  * q = ' ';

  p = q + 1;
  if( p >= command + strlen( command ) )
    {
      cout << "=- ERROR: missing argument <new function> from "
	   << "'replace function' command." << endl;
      return;
    }
  q = command + strlen( command );
  char * f2name = new char[ ( q - p ) + 1 ];
  strcpy( f2name, p );

  BPatch_function * old_function = appImage->findFunction( f1name );
  if( old_function == 0 )
    {
      cout << "=- ERROR: function '" << f1name << "' not found." << endl;
    }
  else
    {
      BPatch_function * new_function = appImage->findFunction( f2name );
      if( new_function == 0 )
	{
	  cout << "=- ERROR: function '" << f2name << "' not found." << endl;
	}
      else
	{
	  bool result = appThread->replaceFunction( * old_function, * new_function );

	  if( ! result )
	    {
	      cout << "=- ERROR: Function '" << f1name << "' could not be replaced with '"
		   << f2name << "'." << endl;
	    }
	  else
	    {
	      cout << "=- Function '" << f1name << "' was replaced with '"
		   << f2name << "'." << endl;
	    }
	}
    }

  delete[] f1name;
  delete[] f2name;
}
