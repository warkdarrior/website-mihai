/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <string>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <set>
#include <map>
#include <stack>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "main.h"
#include "inserters.h"
#include "generate_trace_snippet.h"
#include "incremental_tracer.h"
#include "util.h"
#include "commands.h"
#include "snippet_library.h"
#include "inserters.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void run_tracer()
{
  static int level = 0;

  bool done = false;
  while( ! done )
    {
      appThread->continueExecution();

      while( ! appThread->isStopped() && ! appThread->isTerminated() )
	{
	  usleep( 500000 );
	}

      if( appThread->isStopped() )
	{
	  char line[ 1024 + 1 ];
	  int size = 0;
	  while( read( fd, & line[ size ], 1 ) == 1 )
	    {
	      size++;
	    }
	  line[ size ] = '\0';
	  for( int i = 0; i < size; i++ ) if( line[ i ] == '\n' ) line[ i ] = '\0';

	  int call_number;
	  char * function_name;

	  switch( line[ 0 ] )
	    {
	    case '>':
	      function_name = line + 1;
	      level++;
	      for( int i = 0; i < level; i++ ) cout << "  "; cout<<">"<<function_name<<">"<<endl;
// 	      if( is_selected_for_trace( function_name ) )
		{
		  if( snippets_before_call_in[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      snippets_before_call_in[ fcn_idx( function_name ) ] =
			insert_before_calls( appImage->findFunction( function_name ) );
		    }
		  if( snippets_after_call_in[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      snippets_after_call_in[ fcn_idx( function_name ) ] =
			insert_after_calls( appImage->findFunction( function_name ) );
		    }
		}

	      stopped_at_point = BPatch_entry;
	      stopped_at_function = function_name;
	      break;

	    case '<':
	      {
		function_name = line + 1;
		for( int i = 0; i < level; i++ ) cout << "  ";
		cout << "<" << function_name << "<" << endl;
		level--;
	      }
	      for( map<int, BPatchSnippetHandle *>::iterator index =
		     snippets_before_call_in[ fcn_idx( function_name ) ].begin();
		   index != snippets_before_call_in[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  appThread->deleteSnippet( index->second );
		}
	      for( map<int, BPatchSnippetHandle *>::iterator index =
		     snippets_after_call_in[ fcn_idx( function_name ) ].begin();
		   index != snippets_after_call_in[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  appThread->deleteSnippet( index->second );
		}
	      snippets_before_call_in[ fcn_idx( function_name ) ].clear();
	      snippets_after_call_in[ fcn_idx( function_name ) ].clear();

	      stopped_at_point = BPatch_exit;
	      stopped_at_function = function_name;
	      break;

	    case '+':
	      {
		char * temp;
		temp = strstr( line, ":" ); sscanf( temp + 1, "%d", & call_number ); * temp = '\0';
		temp = strstr( temp + 1, ":" ); function_name = strstr( temp, ":" ) + 1;
		if( function_name == 0 ) { function_name = "null"; }
	      }
	      for( int i = 0; i < level; i++ ) cout << "  "; cout << "+" << function_name << endl;
// 	      if( is_selected_for_trace( function_name ) )
		{
		  if( snippets_at_beginning_of[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      BPatch_snippet * snippet =
			gen_entry_snippet( appThread, pipe_name, function_name );
		      snippets_at_beginning_of[ fcn_idx( function_name ) ] =
			insert_at_entry_points( appImage->findFunction( function_name ), snippet );
		    }
		  if( snippets_at_end_of[ fcn_idx( function_name ) ].size() == 0 )
		    {
		      BPatch_snippet * snippet =
			gen_exit_snippet( appThread, pipe_name, function_name );
		      snippets_at_end_of[ fcn_idx( function_name ) ] =
			insert_at_exit_points( appImage->findFunction( function_name ), snippet );
		    }
		}

	      stopped_at_point = BPatch_subroutine;
	      stopped_at_function = function_name;
	      break;

	    case '-':
	      {
		char * temp;
		temp = strstr( line, ":" ); sscanf( temp + 1, "%d", & call_number ); * temp = '\0';
		temp = strstr( temp + 1, ":" ); function_name = strstr( temp, ":" ) + 1;
		if( function_name == 0 ) { function_name = "null"; }
	      }
	      for( int i = 0; i < level; i++ ) cout << "  "; cout << "-" << function_name << endl;
	      for( set<BPatchSnippetHandle *>::iterator index =
		     snippets_at_beginning_of[ fcn_idx( function_name ) ].begin();
		   index != snippets_at_beginning_of[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  appThread->deleteSnippet( * index );
		}
	      for( set<BPatchSnippetHandle *>::iterator index =
		     snippets_at_end_of[ fcn_idx( function_name ) ].begin();
		   index != snippets_at_end_of[ fcn_idx( function_name ) ].end();
		   index++ )
		{
		  appThread->deleteSnippet( * index );
		}
	      snippets_at_beginning_of[ fcn_idx( function_name ) ].clear();
	      snippets_at_end_of[ fcn_idx( function_name ) ].clear();

	      stopped_at_point = BPatch_subroutine;
	      stopped_at_function = function_name;
	      break;

	    case 'b':
	      if( strstr( line, "b:>" ) == line )
		{
		  function_name = line + 3;
		  cout << "Program stopped on entry to " << function_name << "." << endl;
		  stopped_at_point = BPatch_entry;
		}
	      else if( strstr( line, "b:<" ) == line )
		{
		  function_name = line + 3;
		  cout << "Program stopped on exit from " << function_name << "." << endl;
		  stopped_at_point = BPatch_exit;
		}

	      stopped_at_function = function_name;
	      break;

	    default:
	      cout << "Scrambled transmission:" << endl; 
	      cout << line << endl;
	      break;

	    } // end of switch
	}

      done = true; // appThread->isTerminated();
    }
}
