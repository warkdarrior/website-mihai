/* util.cpp
 *
 * intended to have some cool utility functions for our
 * dynInst crap...
 *
 * Rob
 */

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <BPatch.h>
#include <BPatch_Vector.h>
#include <BPatch_image.h>
#include <BPatch_point.h>
#include <BPatch_snippet.h>
#include <BPatch_thread.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <set>
using namespace std;

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <libgen.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include "util.h"

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#ifndef TEST
#define TEST 0 // 1=test this code
#endif

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#define INIT         register char *sp = instring;

#define GETC()       (*sp++)
#define PEEKC()      (*sp)
#define UNGETC(c)    (--sp)
#define RETURN(c)    return 0;
#define ERROR(c)     fprintf(stderr,"regular expression error!\n");

#include <regexp.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

BPatch_module *findModule(BPatch_image *image, const char *name ) {

  BPatch_Vector<BPatch_module*> *modules;

  modules = image->getModules();

  BPatch_module *ret = 0;

  for ( int i = 0 ; i < modules->size() ; i++ ) {
    BPatch_module *m = (*modules)[i];

    char modname[4096];

    m->getName(modname,4096);

    if ( !strcmp(modname, name) ) {
      ret = m;
      break;
    }
  }

  //delete modules; // the image probably has one of these...

  return ret;
}

_funcvec * get_core_functions(BPatch_image *image) {
  BPatch_module *core = findModule(image,"DEFAULT_MODULE");

  if ( !core ) {
    fprintf(stderr,"no core module!\n");
    return 0;
  }

  return core->getProcedures();
}

void list_modules(BPatch_image *image) {

  BPatch_Vector<BPatch_module*> *modules;

  modules = image->getModules();

  for ( int i = 0 ; i < modules->size() ; i++ ) {
    BPatch_module *m = (*modules)[i];

    char modname[4096];

    m->getName(modname,4096);

    printf("module %s\n",modname);
    
  }

  delete modules;
  
}

void list_funcs_by_module(BPatch_image *image) {

  BPatch_Vector<BPatch_module*> *modules;

  modules = image->getModules();

  for ( int i = 0 ; i < modules->size() ; i++ ) {
    BPatch_module *m = (*modules)[i];

    char modname[4096];

    m->getName(modname,4096);

    _funcvec *funcs;

    funcs = m->getProcedures();

    for ( int j = 0 ; j < funcs->size() ; j++ ) {
      BPatch_function *f = (*funcs)[j];

      char funcname[4096];

      f->getName(funcname,4096);

      printf("%32s: %s\n", modname, funcname);
    }

    delete funcs;
  }
  delete modules;
}

void break_on_function(BPatch_thread *thread, const char* name) {
  BPatch_function *func = thread->getImage()->findFunction(name);

  if ( !func ) {
    fprintf(stderr,"Cannot break on function %s: it doesn't exist!\n",
	    name);
    return;
  }


  BPatch_breakPointExpr breaksnippet;

  BPatch_Vector<BPatch_point*> *entrypoints;

  entrypoints = func->findPoint( BPatch_entry );
  
  for ( int i=0;i<entrypoints->size();i++ ) {
    BPatch_point *p = (*entrypoints)[i];

    thread->insertSnippet( breaksnippet, *p );
  }
  
}

void remove_functions(_funcvec *fvec, char* regexp) {
  addremove_functions(fvec,regexp,true);
}
void trim_functions(_funcvec *fvec, char* regexp) {
  addremove_functions(fvec,regexp,false);
}

void addremove_functions(_funcvec *fvec, char *regexp, bool remove) {

  char expbuf[1024];

  compile(regexp, expbuf, expbuf+1024, '\0' );

  _funcvec myvector;

  for ( int i=0;i < fvec->size() ; i++ ) {
    BPatch_function *func = (*fvec)[i];

    if ( !func )
      continue;

    char fname[256];

    func->getName(fname,256);

    if ( remove ) {
      if ( !step(fname,expbuf) )
	myvector.push_back( func );
    }
    else {
      if ( step(fname,expbuf) )
	myvector.push_back(func);
    }
  }

  (*fvec) = myvector;

}


#if TEST

BPatch bpatch;

int main(int argc, char**argv) {
  assert( argc > 0 );

  BPatch_thread *appThread = bpatch.createProcess( argv[1], argv+1 );

  if ( !appThread ) {
    fprintf(stderr,"couldn't create process %s\n", argv[1] );
    exit(-1);
  }

  BPatch_image *appImage;

  appImage = appThread->getImage();

  printf("modules:\n");
  list_modules(appImage);

  printf("functions:\n");
  list_funcs_by_module(appImage);

  printf("core functions:\n");

  _funcvec *corefuncs = get_core_functions(appImage);

  for ( int i = 0 ; i < corefuncs->size() ; i++ ) {
    BPatch_function *f = (*corefuncs)[i];

    char funcname[256];

    f->getName(funcname,256);

    printf("core function: %s\n", funcname);
  }

  delete appThread;
}

#endif

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

set<char *> & get_matching_function_names( BPatch_image * appImage,
					   char * regexp_string )
{
  set<char *> & matched_set = * new set<char *>;

  char * compiled_regexp = regcmp( regexp_string, ( char * )0 );
  extern char * __loc1; // from the regex library

  BPatch_Vector<BPatch_function * > * p_functions =
    appImage->getProcedures();
  if( p_functions == 0 )
    { cout << "=- ERROR: getProcedures() failed to return a valid result." << endl; return matched_set; }
  BPatch_Vector<BPatch_function * > & functions = * p_functions;

  for( int i = 0; i < functions.size(); i++ )
    {
      if( functions[ i ] != 0 )
	{
	  char function_name[ 1024 + 1 ];
	  functions[ i ]->getName( function_name, 1024 );

	  char * end_of_match = regex( compiled_regexp, function_name );
	  if( ( end_of_match != 0 )
	      &&
	      ( * end_of_match == '\0' )
	      &&
	      ( __loc1 == function_name ) )
	    {
	      matched_set.insert( strdup( function_name ) );
	    }
	}
    }

  free( compiled_regexp );

  return matched_set;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

set<char *> & get_function_callers( BPatch_image * appImage,
				    char * function_name )
{
  set<char *> & result_value = * new set<char * >;

  if( function_name == 0 )
    {
      return result_value;
    }

  BPatch_Vector<BPatch_function * > * p_functions =
    appImage->getProcedures();
  if( p_functions == 0 )
    { cout << "=- ERROR: getProcedures() failed to return a valid result." << endl; return result_value; }
  if( p_functions->size() == 0 )
    { cout << "=- ERROR: getProcedures() failed to return a valid result." << endl; return result_value; }
  BPatch_Vector<BPatch_function * > & functions = * p_functions;

  set<char * > caller_set;

  for( int i = 0; i < functions.size(); i++ )
    {
      BPatch_function * function = functions[ i ];

      if( function != 0 )
	{
	  char caller_name[ 1024 + 1 ];
	  function->getName( caller_name, 1024 );

	  BPatch_Vector<BPatch_point * > * p_call_points =
	    function->findPoint( BPatch_subroutine );
	  if( p_call_points != 0 )
	    {
	      BPatch_Vector<BPatch_point * > & call_points =
		* p_call_points;

	      for( int j = 0; j < call_points.size(); j++ )
		{
		  if( call_points[ j ] != 0 )
		    {
		      BPatch_function * subroutine = call_points[ j ]->getCalledFunction();

		      if( subroutine != 0 )
			{
			  char subroutine_name[ 1024 + 1 ];
			  subroutine->getName( subroutine_name, 1024 );

			  if( strcmp( subroutine_name, function_name ) == 0 )
			    {
			      result_value.insert( strdup( caller_name ) );
			      j = call_points.size() - 1;
			    }
			}
		    }
		}
	    }
	}
    }

  return result_value;
}
