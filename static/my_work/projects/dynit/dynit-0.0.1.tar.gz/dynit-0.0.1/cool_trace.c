#ifdef	__cplusplus
extern "C" {
#endif

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void cool_trace( int level,
		 char * file_name,
		 char * message,
		 int trace_flag,
		 int end_of_func )
{
  int i;
  FILE * trace_file;

  if( 1 )
    {
      printf( "cool_trace: trace_flag = %d, level = %d\n", trace_flag, level );
    }

  trace_file = fopen( file_name, "a+" );
  if( trace_file == 0 )
    {
      return;
    }

  fprintf( trace_file, "%d: ", level );

  for( i = 0; i < level; i++ )
    {
      fprintf( trace_file, "  " );
    }

  fprintf( trace_file, "%s%s\n", message, ( end_of_func == 1 ) ? " end" : " begin" );

  fclose( trace_file );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void piped_trace( int level,
		  char * file_name,
		  char * ct2_message,
		  int end_of_func )
{
  char pn[ 1024 + 1 ];
  FILE * trace_file;
  int i;

  // cool_trace( level, file_name, ct2_message, trace_flag, end_of_func );
  trace_file = fopen( file_name, "a+" ); if( trace_file == 0 ) return;
  fprintf( trace_file, "%d: ", level );
  for( i = 0; i < level; i++ ) fprintf( trace_file, "  " );
  fprintf( trace_file, "%s%s\n", ct2_message, ( end_of_func == 1 ? " end" : " begin" ) );
  fclose( trace_file );

  sprintf( pn, "%s.pipe", file_name );
  // cool_trace( level, pn, ct2_message, trace_flag, end_of_func );
  trace_file = fopen( pn, "a+" ); if( trace_file == 0 ) return;
  fprintf( trace_file, "%s\n", ct2_message );
  fclose( trace_file );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void trace_to_file( char * file_name,
		    char * message )
{
  FILE * trace_file;
  // printf( "trace_to_file( %s, %s ).\n", file_name, message );

  trace_file = fopen( file_name, "a+" ); if( trace_file == 0 ) return;
  fprintf( trace_file, "%s\n", message );
  fclose( trace_file );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void trace_value_to_file( char * file_name,
			  char * format,
			  void * value )
{
  FILE * trace_file;
  printf( "trace_value_to_file( %s, \"%s\" ).\n", file_name, format );

  trace_file = fopen( file_name, "a+" ); if( trace_file == 0 ) return;
  fprintf( trace_file, "%s=", format );
  fprintf( trace_file, format, value );
  fprintf( trace_file, "\n" );
  fclose( trace_file );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void print_spaces( char * file_name, 
		   int count )
{
  int i;
  FILE * trace_file = fopen( file_name, "a+" ); if( trace_file == 0 ) return;
  for( i = 0; i < count; i++ )
    fprintf( trace_file, "  " );
  fclose( trace_file );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

void void_fill_in( void )
{
  printf( "void_fill_in called.\n" );
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

int always_0_fill_in( void )
{
  printf( "always_0_fill_in called.\n" );
  return 0;
}

/*******************************************************************************/
/*******************************************************************************/
/*******************************************************************************/

int always_1_fill_in( void )
{
  printf( "always_1_fill_in called.\n" );
  return 1;
}

#ifdef	__cplusplus
}
#endif
