#ifndef _Snippet_Library_h_

#define _Snippet_Library_h_

void initialize_trace_variables( BPatch_thread * app_thread );

BPatch_funcCallExpr * gen_trace_to_file_snippet( BPatch_thread * app_thread,
						 char * file_name,
						 char * message );

BPatch_funcCallExpr * gen_print_spaces_snippet( BPatch_thread * app_thread,
						char * file_name );

BPatch_snippet * gen_entry_snippet( BPatch_thread * app_thread,
				    char * pipe_file,
				    char * func_name,
				    char * message_prefix = ">"
				    );

BPatch_snippet * gen_exit_snippet( BPatch_thread * app_thread,
				    char * trace_file,
				    char * func_name,
				    char * message_prefix = "<"
				    );

BPatch_snippet * gen_before_snippet( BPatch_thread * app_thread,
				     char * trace_file,
				     char * subroutine_name
				     );

BPatch_snippet * gen_after_snippet( BPatch_thread * app_thread,
				     char * trace_file,
				     char * subroutine_name
				     );

BPatch_funcCallExpr * gen_trace_formatted_value_snippet( BPatch_thread * app_thread,
							 char * file_name,
							 char * format,
							 BPatch_snippet * value );

BPatch_snippet * gen_exec_and_stop( BPatch_snippet * s );

#endif
