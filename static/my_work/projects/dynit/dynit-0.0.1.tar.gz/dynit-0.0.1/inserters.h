#ifndef _inserters_h_

#define _inserters_h_

snippethandle_set_type & insert_at_entry_points ( BPatch_function * function,
						  BPatch_snippet * snippet );

snippethandle_set_type & insert_at_exit_points  ( BPatch_function * function,
						  BPatch_snippet * snippet );

snippethandle_map_type & insert_before_calls    ( BPatch_function * function );

snippethandle_map_type & insert_after_calls     ( BPatch_function * function );

#endif
