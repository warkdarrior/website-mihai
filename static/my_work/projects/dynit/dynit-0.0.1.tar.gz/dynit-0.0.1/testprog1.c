/* testprog.c */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int compute_square( int x )
{
  int result = 0;
  int i;

  for( i = 0; i < x; i++ )
    {
      result += x;
    }

  return result;
}

int main()
{
  int i;

  for( i = 1; i < 10; i++ )
    {
      int isq = compute_square( i );
      printf( "compute_square has returned.\n" );
      printf( "%d * %d = %d\n", i, i, isq );
    }

  return 0;
}
