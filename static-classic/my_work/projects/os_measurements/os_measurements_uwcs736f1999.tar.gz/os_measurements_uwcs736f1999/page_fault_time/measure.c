#include <stdio.h>
#include <unistd.h>
#include <malloc.h>

int main( int argc, char ** argv )
{

  int pagesize = getpagesize();
  int pagecount = 1024;
  int i;
  hrtime_t total;
  int sum;
  char * area = ( char * )malloc( pagesize * pagecount );

  total = 0ll;
  sum = 0;
  for( i = 0; i < pagecount; i++ )
    {
      char c;
      hrtime_t starttime, endtime;

      starttime = gethrtime();

      c = *( area + i * pagesize );

      endtime = gethrtime();

      total += endtime - starttime;

      sum += c;
    }

  free( area );

  printf( "%Lf\n", ( long double )total / ( long double )pagecount );

  return sum % 10;
}
