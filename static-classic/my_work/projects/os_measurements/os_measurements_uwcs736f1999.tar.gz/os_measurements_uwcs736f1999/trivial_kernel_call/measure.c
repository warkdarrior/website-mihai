#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
#include <sys/utsname.h>
#include <limits.h>

int main( int argc, char ** argv )
{

  long long count;
  long long i;
  hrtime_t starttime;
  hrtime_t endtime;
  hrtime_t total;

  sscanf( argv[ 1 ], "%lld", & count );

  gethrtime();

  if( strcmp( argv[ 2 ], "getpid" ) == 0 )
    {
      total = 0ll;
      getpid();

      for( i = 0ll; i < count; i++ )
	{
	  starttime = gethrtime();
	  getpid();
	  endtime = gethrtime();
	  total += endtime - starttime;
	  /*
	  if( i % ( count / 100ll ) == 0ll )
	    {
	      printf( "%d... ", i / ( count / 100ll ) ); fflush( stdout );
	    }
	  */
	}

      printf( "%Lf\n", ( long double )total / ( long double )count );
    }
  else if( strcmp( argv[ 2 ], "times" ) == 0 )
    {
      total = 0ll;
      times( 0 );

      for( i = 0ll; i < count; i++ )
	{
	  starttime = gethrtime();
	  times( 0 );
	  endtime = gethrtime();
	  total += endtime - starttime;
	  /*
	  if( i % ( count / 100ll ) == 0ll )
	    {
	      printf( "%d... ", i / ( count / 100ll ) ); fflush( stdout );
	    }
	  */
	}

      printf( "%Lf\n", ( long double )total / ( long double )count );
    }
  else if( strcmp( argv[ 2 ], "getppid" ) == 0 )
    {
      total = 0ll;
      getppid();

      for( i = 0ll; i < count; i++ )
	{
	  starttime = gethrtime();
	  getppid();
	  endtime = gethrtime();
	  total += endtime - starttime;
	  /*
	  if( i % ( count / 100ll ) == 0ll )
	    {
	      printf( "%d... ", i / ( count / 100ll ) ); fflush( stdout );
	    }
	  */
	}

      printf( "%Lf\n", ( long double )total / ( long double )count );
    }
  else if( strcmp( argv[ 2 ], "uname" ) == 0 )
    {
      struct utsname info;

      total = 0ll;
      uname( & info );

      for( i = 0ll; i < count; i++ )
	{
	  starttime = gethrtime();
	  uname( & info );
	  endtime = gethrtime();
	  total += endtime - starttime;
	  /*
	  if( i % ( count / 100ll ) == 0ll )
	    {
	      printf( "%d... ", i / ( count / 100ll ) ); fflush( stdout );
	    }
	  */
	}

      printf( "%Lf\n", ( long double )total / ( long double )count );
    }

  return 0;
}
