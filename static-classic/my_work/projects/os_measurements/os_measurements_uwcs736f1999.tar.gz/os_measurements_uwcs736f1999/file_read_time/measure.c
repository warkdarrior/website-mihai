#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <malloc.h>
#include <errno.h>
#include <sys/mman.h>

#define FILE_NAME "/var/tmp/test_file.dat"

void clear_memory();
void measure_read( int block_size );
void measure_fread( int block_size );
void measure_mmap( int block_size );

int main( int argc, char ** argv )
{

  int block_size;

  if( argc < 2 )
    {
      printf( "Usage:\n\t%s [read|fread|mmap] <buffer size>\n", argv[ 0 ] );
      return 1;
    }

  sscanf( argv[ 2 ], "%d", & block_size );

  if( strcmp( argv[ 1 ], "read" ) == 0 )
    {
      measure_read( block_size );
    }
  else if( strcmp( argv[ 1 ], "fread" ) == 0 )
    {
      measure_fread( block_size );
    }
  else if( strcmp( argv[ 1 ], "mmap" ) == 0 )
    {
      measure_mmap( block_size );
    }
  else
    {
      printf( "%s not yet supported.\n", argv[ 1 ] );
    }

  return 0;
}

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/

void clear_memory()
{
  long long memory_size;
  char * area;

  fprintf( stderr, "Clearing memory. Please wait... " ); fflush( stderr );

  memory_size = sysconf( _SC_PHYS_PAGES ) * sysconf( _SC_PAGESIZE );
  area = ( char * )malloc( sizeof( char ) * memory_size );

  if( area == 0 )
    {
      printf( "Cannot allocate memory!\n" );
      exit( 1 );
    }

  memset( area, 'M', memory_size );

  free( area );

  fprintf( stderr, "done.\n" ); fflush( stderr );
}

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/

void measure_read( int block_size )
{
  int fd;

  off_t file_size;
  int count;
  int i;
  char * buffer = ( char * )malloc( sizeof( char ) * block_size );

  hrtime_t total = 0ll;
  hrtime_t starttime;
  hrtime_t endtime;
  hrtime_t inittime;

  clear_memory();

  fd = open( FILE_NAME, O_RDONLY | O_LARGEFILE );
  { struct stat buf; fstat( fd, & buf ); file_size = buf.st_size; }

  starttime = gethrtime();

  if( read( fd, buffer, block_size ) != block_size )
    {
      printf( "ERROR: read failed. errno = %d\n", errno );
      perror( "" );
      exit( 1 );
    }

  endtime = gethrtime();

  inittime = endtime - starttime;

  count = file_size / block_size - 1;
  for( i = 0; i < count; i++ )
    {
      starttime = gethrtime();

      if( read( fd, buffer, block_size ) != block_size )
	{
	  printf( "ERROR: read failed. errno = %d\n", errno );
	  perror( "" );
	  exit( 1 );
	}

      endtime = gethrtime();

      total += endtime - starttime;
      /*
	printf( "instantaneous measurement: %Lf\n",
	( long double )endtime - ( long double )starttime );
	fflush( stdout );
      */
      if( i % ( count / 100 ) == 0 )
	{
	  fprintf( stderr, "%d... ", i ); fflush( stderr );
	}
    }

  close( fd );

  fprintf( stderr, "\n" );

  printf( "%Lf\n", ( long double )inittime );
  printf( "%Lf\n", ( long double )total / ( long double )count );
}

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/

void measure_fread( int block_size )
{
  FILE * f;

  off_t file_size;
  int count;
  int i;
  char * buffer = ( char * )malloc( sizeof( char ) * block_size );

  hrtime_t total = 0ll;
  hrtime_t starttime;
  hrtime_t endtime;
  hrtime_t inittime;

  clear_memory();

  f = fopen( FILE_NAME, "r" );
  { struct stat buf; stat( FILE_NAME, & buf ); file_size = buf.st_size; }
  if( f == 0 )
    {
      printf( "ERROR: fopen failed. errno = %d\n", errno );
      perror( "" );
      exit( 1 );
    }

  starttime = gethrtime();

  if( fread( buffer, block_size, 1, f ) != 1 )
    {
      printf( "ERROR: fread failed. errno = %d\n", errno );
      perror( "" );
      exit( 1 );
    }

  endtime = gethrtime();

  inittime = endtime - starttime;

  count = file_size / block_size - 1;
  for( i = 0; i < count; i++ )
    {
      starttime = gethrtime();

      if( fread( buffer, block_size, 1, f ) != 1 )
	{
	  printf( "ERROR: fread[%d] failed. errno = %d\n", i, errno );
	  perror( "" );
	  exit( 1 );
	}

      endtime = gethrtime();

      total += endtime - starttime;
      /*
	printf( "instantaneous measurement: %Lf\n",
	( long double )endtime - ( long double )starttime );
	fflush( stdout );
      */
      if( i % ( count / 100 ) == 0 )
	{
	  fprintf( stderr, "%d... ", i ); fflush( stderr );
	}
    }

  fclose( f );

  fprintf( stderr, "\n" );

  printf( "%Lf\n", ( long double )inittime );
  printf( "%Lf\n", ( long double )total / ( long double )count );
}

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/

void measure_mmap( int block_size )
{
  int fd;
  char * area;

  off_t file_size;
  int count;
  int i;
  char * buffer = ( char * )malloc( sizeof( char ) * block_size );

  hrtime_t total = 0ll;
  hrtime_t starttime;
  hrtime_t endtime;
  hrtime_t inittime;

  clear_memory();

  fd = open( FILE_NAME, O_RDONLY | O_LARGEFILE );
  { struct stat buf; stat( FILE_NAME, & buf ); file_size = buf.st_size; }
  area = ( char * )mmap( ( caddr_t )0, file_size, PROT_READ, MAP_SHARED, fd, 0 );
  if( area == MAP_FAILED )
    {
      printf( "ERROR: mmap failed. errno = %d.\n", errno );
      perror( "" );
      exit( 1 );
    }

  starttime = gethrtime();

  memcpy( buffer, area, block_size );

  endtime = gethrtime();

  inittime = endtime - starttime;

  count = file_size / block_size - 1;
  for( i = 0; i < count; i++ )
    {
      starttime = gethrtime();

      memcpy( buffer, area + block_size + i * block_size, block_size );

      endtime = gethrtime();

      total += endtime - starttime;
      /*
	printf( "instantaneous measurement: %Lf\n",
	( long double )endtime - ( long double )starttime );
	fflush( stdout );
      */
      if( i % ( count / 100 ) == 0 )
	{
	  fprintf( stderr, "%d... ", i ); fflush( stderr );
	}
    }

  munmap( area, file_size );
  close( fd );

  fprintf( stderr, "\n" );

  printf( "%Lf\n", ( long double )inittime );
  printf( "%Lf\n", ( long double )total / ( long double )count );
}
