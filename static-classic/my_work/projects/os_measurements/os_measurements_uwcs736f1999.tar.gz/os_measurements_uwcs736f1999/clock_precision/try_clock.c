#include <stdio.h>
#include <time.h>

int main( int argc, char ** argv )
{

    long long add_tot_time;
    long count;
    long i;
    int a;

    if( argc != 2 )
	{
	    printf( "Usage:\n\t%s <loop count>\n", argv[ 0 ] );
	    return 1;
	}

    sscanf( argv[ 1 ], "%ld", & count );

    clock();

    a = 1;
    add_tot_time = 0l;
    for( i = 0l; i < count; i++ )
	{
	    clock_t starttime;
	    clock_t endtime;

	    starttime = clock();
	    a = a + 4 * ( i % 7 );
	    endtime = clock();

	    add_tot_time += endtime - starttime;

	    if( i % ( count / 10l ) == 0l )
		{
		    printf( "%ld ", i / ( count / 10l ) ); fflush( stdout );
		}
	}

    printf( "Average time: %Lf s\n",
	    ( long double )add_tot_time / ( long double )count / ( long double )CLOCKS_PER_SEC );

    return a;
}
