#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>

int main( int argc, char ** argv )
{

  long long count;
  long long starttime;
  long long endtime;
  int a;
  struct timespec t;

  gethrtime();
  a = 1;
  starttime = gethrtime();

  asm ( "nop" );
  a = a + argc;
  asm ( "nop" );

  endtime = gethrtime();
  printf( "%Lf\n", ( ( long double )endtime - ( long double )starttime ) / ( long double )1 );

  return a;
}
