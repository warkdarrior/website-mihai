#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>

long count = 1000l;

void measure_with_gethrtime( char * s );
void measure_with_gettimeofday( char * s );

int main( int argc, char ** argv )
{
  if( strcmp( argv[ 1 ], "-hrtime" ) == 0 )
    {
      measure_with_gethrtime( argv[ 2 ] );
    }
  else if( strcmp( argv[ 1 ], "-timeofday" ) == 0 )
    {
      measure_with_gettimeofday( argv[ 2 ] );
    }
  else
    {
      printf( "Known time measurement: -hrtime, -timeofday\n" );
    }

  return 0;
}

void measure_with_gethrtime( char * s )
{
  int a, b;

  hrtime_t starttime, endtime;
  long long empty_avg = 0ll;
  long long add_avg = 0ll;
  long long usleep_avg = 0l;
  long i;

  sscanf( s, "%d", & b );

  /* Just to allow the linker to do its patching... */
  printf( "Getting ready to start with gethrtime...\n"
	  "count = %ld / scale = %ld => max index = %ld \n",
	  count, count / 100l, count / ( count / 100l ) );
  gethrtime();
  /* OK, everything should be a direct call from now on... */

  for( i = 0l; i < count; i++ )
    {
      starttime = gethrtime();
      endtime = gethrtime();
      empty_avg += endtime - starttime;

      starttime = gethrtime();
      a = b + 10123;
      endtime = gethrtime();
      add_avg += endtime - starttime;

      starttime = gethrtime();
      usleep( 1 );
      endtime = gethrtime();
      usleep_avg += endtime - starttime;

      if( ( i % ( count / 100l ) ) == 0l )
	{
	  printf( "%ld... ", i / ( count / 100l ) ); fflush( stdout );
	}
    }
  printf( "\n" );

  printf( "Empty measurement average: %Lf ns\n",
	  ( long double )empty_avg / ( long double)count );
  printf( "Addition measurement average: %Lf ns\n",
	  ( long double )add_avg / ( long double)count );
  printf( "usleep measurement average: %Lf ns\n",
	  ( long double )usleep_avg / ( long double)count );

}

void measure_with_gettimeofday( char * s )
{
  int a, b;

  hrtime_t starttime, endtime;
  long long empty_avg = 0l;
  long long add_avg = 0l;
  long long usleep_avg = 0l;
  long i;

  sscanf( s, "%d", & b );

  /* Just to allow the linker to do its patching... */
  printf( "Getting ready to start with gettimeofday...\n"
	  "count = %ld / scale = %ld => max index = %ld \n",
	  count, count / 100l, count / ( count / 100l ) );
  gettimeofday( 0, 0 );
  /* OK, everything should be a direct call from now on... */

  for( i = 0l; i < count; i++ )
    {
      struct timeval tv;
      gettimeofday( & tv, 0 ); starttime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      gettimeofday( & tv, 0 ); endtime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      empty_avg += endtime - starttime;

      gettimeofday( & tv, 0 ); starttime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      a = b + 10123;
      gettimeofday( & tv, 0 ); endtime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      add_avg += endtime - starttime;

      gettimeofday( & tv, 0 ); starttime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      usleep( 1 );
      gettimeofday( & tv, 0 ); endtime = ( long long )tv.tv_sec * 1000000000ll
				 + ( long long )tv.tv_usec * 1000ll;
      usleep_avg += endtime - starttime;

      if( ( i % ( count / 100l ) ) == 0l )
	{
	  printf( "%ld... ", i / ( count / 100l ) ); fflush( stdout );
	}
    }
  printf( "\n" );

  printf( "Empty measurement average: %Lf ns\n",
	  ( long double )empty_avg / ( long double)count );
  printf( "Addition measurement average: %Lf ns\n",
	  ( long double )add_avg / ( long double)count );
  printf( "usleep measurement average: %Lf ns\n",
	  ( long double )usleep_avg / ( long double)count );

}
