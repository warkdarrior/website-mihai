#!/bin/sh

cat <<TOP
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>

int main( int argc, char ** argv )
{

  long long count;
  long long starttime;
  long long endtime;
  int a;
  struct timespec t;

  gethrtime();
  a = 1;
TOP


case "$1" in
    gethrtime)
	cat <<GETHRTIME
  starttime = gethrtime();
GETHRTIME
	;;
    clock_gettime)
	cat <<CLOCK_GETTIME
  { struct timespec t; clock_gettime( CLOCK_REALTIME, & t ); starttime = t.tv_sec * 1000000ll + t.tv_nsec; }
CLOCK_GETTIME
	;;
esac


echo
j=0
while [ $j -lt $2 ]
do
  cat <<BODY
  asm ( "nop" );
  a = a + argc;
BODY
  j=`expr $j + 1`
done
echo '  asm ( "nop" );'
echo


case "$1" in
    gethrtime)
	cat <<GETHRTIME
  endtime = gethrtime();
GETHRTIME
	;;
    clock_gettime)
	cat <<CLOCK_GETTIME
  { struct timespec t; clock_gettime( CLOCK_REALTIME, & t ); endtime = t.tv_sec * 1000000ll + t.tv_nsec; }
CLOCK_GETTIME
	;;
esac


cat <<BOTTOM
  printf( "%Lf\n", ( ( long double )endtime - ( long double )starttime ) / ( long double )$2 );

  return a;
}
BOTTOM
