#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>

int main( int argc, char ** argv )
{

  long long count;
  long long starttime;
  long long endtime;
  struct timespec t;

  sscanf( argv[ 1 ], "%lld", & count );
  
  starttime = gethrtime();
  // { struct timespec t; clock_gettime( CLOCK_REALTIME, & t ); starttime = t.tv_sec * 1000000ll + t.tv_nsec; }

  a = a + random();

  endtime = gethrtime();
  // { struct timespec t; clock_gettime( CLOCK_REALTIME, & t ); endtime = t.tv_sec * 1000000ll + t.tv_nsec; }

  printf( "%lld\n", endtime - starttime );

  return 0;
}
