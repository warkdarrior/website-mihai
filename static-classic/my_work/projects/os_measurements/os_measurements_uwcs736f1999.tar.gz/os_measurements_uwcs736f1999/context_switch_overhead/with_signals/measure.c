#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

hrtime_t starttime;
hrtime_t endtime;
hrtime_t total;
int i;
int count;
pid_t child_pid;
pid_t parent_pid;

void parent_handler()
{
  endtime = gethrtime();

  signal( SIGUSR1, parent_handler );
  i++;
  total += endtime - starttime;

  if( i < count )
    {
      starttime = gethrtime();
      kill( child_pid, SIGUSR1 );
    }
}

void child_handler()
{
  signal( SIGUSR1, child_handler );

  kill( parent_pid, SIGUSR1 );
}

int main( int argc, char **argv )
{

  sscanf( argv[ 1 ], "%d", & count );

  switch( ( child_pid = fork() ) )
    {

    case ( pid_t ) - 1: // fork failed
      printf( "ERROR: cannot create child process.\n" );
      break;

    case 0: // we are in the child process
      parent_pid = getppid();
      signal( SIGUSR1, child_handler );
      while( 1 )
	{
	  pause();
	}
      break;

    default: // we are in the parent process
      signal( SIGUSR1, parent_handler );
      total = 0ll;
      starttime = gethrtime();
      kill( child_pid, SIGUSR1 );
      for( i = 0; i < count; i++ )
	{
	  pause();
	  /*
	  if( i % ( count / 100 ) == 0 )
	    {
	      printf( "%d... ", i ); fflush( stdout );
	    }
	  */
	}
      kill( child_pid, SIGTERM );
      /* printf( "\n" ); */
      printf( "%Lf\n", ( long double )total / ( long double )count );
      break;

    }

  return 0;
}
