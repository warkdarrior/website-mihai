#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

int p2c[ 2 ];
int c2p[ 2 ];

int main( int argc, char ** argv )
{

  char buffer[ 1 ];
  int i;
  int count;
  hrtime_t total;
  pid_t child_pid;
  int error_occured;
  
  sscanf( argv[ 1 ], "%d", & count );

  pipe( p2c );
  pipe( c2p );

  switch( ( child_pid = fork() ) )
    {

    case ( pid_t ) - 1: // error
      printf( "ERROR: fork() failed.\n" );
      break;

    case 0: // child process
      // close( p2c[ 0 ] ); // we will read only from p2c[ 1 ]
      // close( c2p[ 0 ] ); // we will write only to c2p[ 1 ]
      error_occured = 0;
      while( ! error_occured )
	{
	  if( read( p2c[ 1 ], buffer, 1 ) != 1 )
	    {
	      printf( "ERROR: child: read set errno to %d.\n", errno );
	      fflush( stdout );
	      perror( "" );
	      error_occured = 1;
	    }
	  if( write( c2p[ 1 ], "2", 1 ) != 1 )
	    {
	      printf( "ERROR: child: write set errno to %d.\n", errno );
	      fflush( stdout );
	      perror( "" );
	      error_occured = 1;
	    }
	}
      break;

    default: // parent process
      // close( p2c[ 1 ] ); // we will write only to p2c[ 0 ]
      // close( c2p[ 1 ] ); // we will read only from c2p[ 0 ]
      total = 0ll;
      error_occured = 0;
      for( i = 0; i < count && ! error_occured; i++ )
	{
	  hrtime_t starttime, endtime;

	  starttime = gethrtime();

	  if( write( p2c[ 0 ], "1", 1 ) != 1 )
	    {
	      printf( "ERROR: parent: write set errno to %d (i=%d).\n",
		      errno, i );
	      fflush( stdout );
	      perror( "" );
	      error_occured = 1;
	    }
	  if( read( c2p[ 0 ], buffer, 1 ) != 1 )
	    {
	      printf( "ERROR: parent: read set errno to %d (i=%d).\n",
		      errno, i );
	      fflush( stdout );
	      perror( "" );
	      error_occured = 1;
	    }

	  endtime = gethrtime();

	  total += endtime - starttime;

	  /*
	  if( i % ( count / 100 ) == 0 )
	    {
	      printf( "%d... ", i ); fflush( stdout );
	    }
	  */
	}
      kill( child_pid, SIGTERM );
      printf( "%Lg\n", ( long double )total / ( long double )count );
      break;

    }

  return 0;
}
